package Presentation;

import java.util.Scanner;

public class Menu
{
    private final Scanner scanner;

    /**
     * Constructor del menu
     */
    public Menu()
    {
        this.scanner = new Scanner(System.in);
    }

    /**
     * Método de bienvenida al usuario
     */
    public void chargingJson()
    {
        this.showMessage("""
             ____  _                  __        __     ____  ___    ___    _____
            / __/ (_) __ _    ___    / / ___   / /    / __/ / _ \\  / _ \\  / ___/
           _\\ \\  / / /  ' \\  / _ \\  / / / -_) / /__  _\\ \\  / , _/ / ___/ / (_ /
          /___/ /_/ /_/_/_/ / .__/ /_/  \\__/ /____/ /___/ /_/|_| /_/     \\___/
                            /_/
        """);
        this.showMessage("");
        this.showMessage("Welcome to Simple LSRPG.");
        this.showMessage("");
    }

    /**
     * Mensajes para escoger el tipo de data
     */
    public void chooseData()
    {
        this.showMessage("Do you want to use your local or cloud data?");
        this.showMessage("\t1) Local data");
        this.showMessage("\t2) Cloud data");
        this.showMessageAsk("\n-> Answer: ");
    }

    /**
     * Método que desplega el menu principal
     *
     * @param sizeCharacter tamaño del array de personajes
     */
    public void showMenu(int sizeCharacter)
    {
        showMessage(
                "The tavern keeper looks at you and says:");
        showMessage(
                "\n“Welcome adventurer! How can I help you?”\n");
        showMessage("\t1) Character creation");
        showMessage("\t2) List characters");
        showMessage("\t3) Create an adventure");
        if(sizeCharacter < 3)
        {
            this.showMessage("\t4) Start an adventure"
                + " (disabled: create 3 characters first)");
        }
        else
        {
            showMessage("\t4) Start an adventure");
        }
        showMessage("\t5) Exit\n");
        showMessageAsk("Your answer: ");
    }

    /**
     * Método que desplega el menu de monstruos
     */
    public void showMenuMonster()
    {
        showMessage("1. Add monster");
        showMessage("2. Remove monster");
        showMessage("3. Continue");
        showMessage("");
        showMessageAsk("-> Enter an option [1..3]: ");
    }

    /**
     * Método que muestra mensajes por pantalla, con salto de línea
     *
     * @param message mensaje a mostrar
     */
    public void showMessage(String message)
    {
        System.out.println(message);
    }

    /**
     * Método que muestra mensajes por pantalla, sin salto de línea
     *
     * @param message mensaje a mostrar
     */
    public void showMessageAsk(String message)
    {
        System.out.print(message);
    }

    /**
     * Método que verifica que la introducción del nombre del personaje sea correcta
     *
     * @param name nombre del personaje
     * @return true si el nombre es correcto, false si no lo es
     */
    private boolean checkStringName(String name)
    {
        for(int i = 0; i < name.length(); i++)
        {
            if(Character.isDigit(name.charAt(i)))
            {
                return true;
            }
        }

        for(int i = 0; i < name.length(); i++)
        {

            if(!Character.isDigit(
                name.charAt(i)) && !java.lang.Character.isLetter(
                name.charAt(i)) && !java.lang.Character.isWhitespace(
                name.charAt(i)))
            {
                return true;
            }
        }

        return false;
    }

    /**
     * Método que controla el formato del nombre del personaje
     *
     * @param name nombre del personaje
     * @return nombre del personaje con el formato correcto
     */
    private String checkCapitalLetters(String name)
    {
        String lowerCase = name.toLowerCase();
        String[] newString = lowerCase.split("");

        for(int i = 0; i < newString.length; i++)
        {
            if(i == 0 || newString[i - 1].equals(" "))
            {
                newString[i] = newString[i].toUpperCase();
            }
        }

        return String.join("", newString);
    }

    /**
     * Método que recibe un nombre de personaje y controla posibles errores
     *
     * @param name nombre del personaje
     * @return nombre del personaje con el formato correcto
     */
    public String askNameCharacter(String name)
    {
        //Comprobamos que el nombre no este vacío, que no contenga números ni caracteres especiales
        //Además comprobamos también que no sea igual a uno ya creado
        if(name.equals(""))
        {
            showMessage(
                "Sorry, you have entered an empty name!" 
                + " Try again...\n");
            return "";
        }
        else if(checkStringName(name))
        {
            showMessage(
                "Sorry, you have entered wrong character!" 
                + " Try again...\n");
            return "";
        }
        else
        {
            return checkCapitalLetters(name);
        }
    }

    /**
     * Método que pide al usuario el nombre del jugador
     *
     * @param name nombre del jugador
     * @return nombre del jugador
     */
    public String askNamePlayer(String name)
    {
        if(name.equals(""))
        {
            showMessage(
                "\nSorry, you have entered an empty name! Try again...\n");
            return "";
        }
        else
        {
            return name;
        }
    }
}