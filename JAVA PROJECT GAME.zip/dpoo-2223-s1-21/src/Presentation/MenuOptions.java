package Presentation;

/**
 * Opciones que puede ser escogidas en los menu:
 * <p>
 * {@link #LOCAL_DATA}
 * {@link #CLOUD_DATA}
 * {@link #CREATE_CHARACTER}
 * {@link #LIST_CHARACTERS}
 * {@link #CREATE_ADVENTURE}
 * {@link #START_ADVENTURE}
 * {@link #ADD_MONSTER}
 * {@link #REMOVE_MONSTER}
 * {@link #CONTINUE}
 * {@link #EXIT}
 */

public enum MenuOptions
{
    LOCAL_DATA,
    CLOUD_DATA,
    CREATE_CHARACTER,
    LIST_CHARACTERS,
    CREATE_ADVENTURE,
    START_ADVENTURE,
    ADD_MONSTER,
    REMOVE_MONSTER,
    CONTINUE,
    EXIT,
}