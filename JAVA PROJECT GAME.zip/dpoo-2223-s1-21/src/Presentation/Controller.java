package Presentation;

import Business.Adventure.AdventureManager;
import Business.Character.CharacterManager;
import Business.Monster.MonsterManager;

import java.util.List;

public class Controller
{
    private final ConsoleUIManager ui;
    private CharacterManager characterManager;
    private MonsterManager monsterManager;
    private AdventureManager adventureManager;

    /* ---------------------- Constructor ---------------------- */

    /**
     * Constructor del Controller
     */
    public Controller()
    {
        this.ui = new ConsoleUIManager();
    }

    /* ---------------------- Start ---------------------- */

    /**
     * Iniciar la aplicación.
     * Controlar que tipos de datos queremos usar.
     */
    public void start()
    {
        this.ui.showBeginning();

        switch (this.ui.showMenuData())
        {
            case LOCAL_DATA -> 
            {
                this.characterManager = new CharacterManager(MenuOptions.LOCAL_DATA);
                this.adventureManager = new AdventureManager(MenuOptions.LOCAL_DATA);
                this.monsterManager = new MonsterManager(this.adventureManager, this.characterManager, MenuOptions.LOCAL_DATA);
                this.adventureManager.startMonster(this.monsterManager);
                this.characterManager.startMonster(this.monsterManager);
                this.load(MenuOptions.LOCAL_DATA);
            }
            case CLOUD_DATA ->
            {
                this.characterManager = new CharacterManager(MenuOptions.CLOUD_DATA);
                this.adventureManager = new AdventureManager(MenuOptions.CLOUD_DATA);
                this.monsterManager = new MonsterManager(this.adventureManager, this.characterManager, MenuOptions.CLOUD_DATA);
                this.adventureManager.startMonster(this.monsterManager);
                this.characterManager.startMonster(this.monsterManager);
                this.load(MenuOptions.CLOUD_DATA);
            }
        }
    }

    /**
     * Método que verifica la carga de ficheros
     */
    private void load(MenuOptions options)
    {
        this.ui.showMessageLoad(1);
        boolean monsterIsExist = this.monsterManager.isExist(options);
        boolean characterIsExist = this.characterManager.isExist(options);
        boolean adventureIsExist = this.adventureManager.isExist(options);

        switch(options)
        {
            case LOCAL_DATA ->
            {
                if(monsterIsExist)
                {
                    if(characterIsExist)
                    {
                        if(adventureIsExist)
                        {
                            this.ui.showMessageLoad(2);
                            run();
                        }
                    }
                }
            }
            case CLOUD_DATA ->
            {
                if(monsterIsExist && characterIsExist && adventureIsExist)
                {
                    this.ui.showMessageLoad(2);
                    run();
                }
                else
                {
                    this.ui.showMessageLoad(3);

                    this.characterManager = new CharacterManager(MenuOptions.LOCAL_DATA);
                    this.adventureManager = new AdventureManager(MenuOptions.LOCAL_DATA);
                    this.monsterManager = new MonsterManager(this.adventureManager, this.characterManager, MenuOptions.LOCAL_DATA);
                    this.adventureManager.startMonster(this.monsterManager);
                    this.load(MenuOptions.LOCAL_DATA);
                }
            }
        }
    }

    /**
     * Método que muestra el menu principal por pantalla
     */
    private void run()
    {
        while(true)
        {
            int sizeCharacter = characterManager.size();
            switch(ui.showMenu(sizeCharacter))
            {
                case CREATE_CHARACTER -> characterCreation();

                case LIST_CHARACTERS -> characterList();

                case CREATE_ADVENTURE -> adventureCreate();

                case START_ADVENTURE ->
                {
                    if(sizeCharacter < 3)
                    {
                        run();
                    }
                    else
                    {
                        this.player();
                    }
                }

                case EXIT ->
                {
                    this.ui.showMessageClosing();
                    System.exit(0);
                }
            }
        }
    }

    /**
     * Método que muestra por pantalla la creación de un personaje nuevo
     */
    private void characterCreation()
    {
        this.ui.showMessageCharacterCreation(1, "", 0);

        String characterName = this.ui.askNameCharacter(
                "-> Enter your name: ");

        boolean alreadyExist = this.characterManager.alreadyExistCharacter(
                characterName);

        if(characterName.equals(""))
        {
            this.run();
        }
        else if(alreadyExist)
        {
            this.ui.showMessageCharacterCreation(2, "", 0);

            this.run();
        }
        else
        {
            this.ui.showMessageCharacterCreation(3, characterName, 0);

            String playerName = this.ui.askNamePlayer("-> Enter the player's name: ");

            if(playerName.equals(""))
            {
                run();
            }
            else
            {
                int characterLevel = this.ui.askCharacterLevel();

                if(characterLevel == -1)
                {
                    this.ui.showMessageError("range");
                    run();
                }
                else
                {
                    this.ui.showMessageCharacterCreation(4, "", characterLevel);

                    //llamar business manager para generar estadísticas
                    int[] bodyDice = this.characterManager.generateSumOfDiceSixFaces();
                    this.ui.showGenerateStat("Body", bodyDice);

                    int[] mindDice = this.characterManager.generateSumOfDiceSixFaces();
                    this.ui.showGenerateStat("Mind", mindDice);

                    int[] spiritDice = this.characterManager.generateSumOfDiceSixFaces();
                    this.ui.showGenerateStat("Spirit", spiritDice);

                    this.ui.showMessageCharacterCreation(5, "", 0);

                    int body = this.characterManager.resultOfDice(
                            bodyDice[2]);
                    this.ui.showResultOfDice("Body", body);

                    int mind = this.characterManager.resultOfDice(
                            mindDice[2]);
                    this.ui.showResultOfDice("Mind", mind);

                    int spirit = this.characterManager.resultOfDice(
                            spiritDice[2]);
                    this.ui.showResultOfDice("Spirit", spirit);

                    this.ui.showMessageCharacterCreation(6, "", 0);

                    String characterClass = this.ui.askForCharacterClass();

                    boolean createCharacter = this.characterManager.postCharacter(
                            characterName, playerName, characterLevel,
                            body, mind, spirit, characterClass);

                    String postedCharacterClass = this.characterManager.getPostedCharacterClass();
                    this.ui.showMessageCreateCharacter(createCharacter, characterName, postedCharacterClass);
                }
            }
        }
    }

    /**
     * Método para iniciar el listado de personajes
     */
    private void characterList()
    {
        this.ui.showMessageCharacterList(1);

        String characterPlayer = this.ui.askForString(
                "\n-> Enter the name of the Player to filter: ");

        List<String> nameList;
        if(characterPlayer.equals(""))
        {
            this.ui.showMessageCharacterList(2);

            nameList = this.characterManager.getCharactersName();

            int positionSelectedCharacter = listCharactersAndSelect(nameList);

            if(positionSelectedCharacter >= 0)
            {
                String infoCharacter = this.characterManager.infoCharacterByIndex(
                    positionSelectedCharacter, "infoCharacter");

                String characterName = this.characterManager.infoCharacterByIndex(
                    positionSelectedCharacter, "characterName");

                this.ui.showInfoCharacter(infoCharacter, characterName);

                deleteCharacter(characterName);
            }
            else
            {
                this.ui.showMessage("");
                this.run();
            }
        }
        else
        {
            nameList = this.characterManager.charactersOfPlayers(characterPlayer);

            if(!nameList.isEmpty())
            {
                this.ui.showMessageCharacterList(3);

                int positionSelectedCharacter = listCharactersAndSelect(nameList);

                if(positionSelectedCharacter >= 0)
                {
                    String characterName = nameList.get(positionSelectedCharacter);

                    String infoCharacter = this.characterManager.infoCharacterByName(characterName);

                    this.ui.showInfoCharacter(infoCharacter, characterName);

                    deleteCharacter(characterName);
                }
                else
                {
                    this.ui.showMessage("");
                    this.run();
                }
            }
            else
            {
                this.ui.showMessageCharacterList(4);
            }
        }
    }

    /**
     * Método que lista todos los personajes
     *
     * @param characterNameList lista de nombres de personajes.
     * @return posición del personaje seleccionado.
     */
    private int listCharactersAndSelect(List<String> characterNameList)
    {
        if(characterNameList != null)
        {
            int totalNameList = characterNameList.size();
            this.ui.listCharacterName("listCharacters", characterNameList);

            return this.ui.askNumberByRange(
                    "\nWho would you like to meet [0.." + totalNameList + "]: ",
                    0, totalNameList, "characterList") - 1;
        }
        else
        {
            this.ui.showMessageCharacterList(5);
            return -1;
        }
    }

    /**
     * Método que elimina un personaje
     *
     * @param name nombre del personaje a eliminar.
     */
    private void deleteCharacter(String name)
    {
        this.ui.showMessageCharacterDelete();

        String selectedName = this.ui.askForString(
                "Do you want to delete " + name + "? ");

        if(!selectedName.equals("") && name.equals(selectedName))
        {
            boolean delete = this.characterManager.deleteCharacterByName(name);

            if(delete)
            {
                this.ui.showMessageConfirmDelete(name);
            }
            else
            {
                this.ui.showMessageError("name");
                run();
            }
        }
        else
        {
            this.ui.showMessage("");
            run();
        }
    }

    /**
     * Método con las funciones del menu de monstruos
     *
     * @return true si se ha seleccionado la opción de continuar.
     */
    private boolean optionMonster()
    {
        switch(ui.showMenuMonster())
        {
            case ADD_MONSTER -> addMonster();

            case REMOVE_MONSTER -> removeMonster();

            case CONTINUE ->
            {
                if(!this.adventureManager.listMonsterSelect().isEmpty())
                {
                    this.ui.showMessage("");
                    return true;
                }
                else
                {
                    this.ui.showMessage("You have not chosen any monster yet, " + 
                        "please add monsters to the combat.\n");

                    optionMonster();
                }
            }
        }
        return false;
    }

    /**
     * Método para iniciar la creación de una aventura
     */
    private void adventureCreate()
    {
        this.ui.showMessage(
                "\nTavern keeper: “Planning an adventure?" + " Good luck with that!”");
        this.ui.showMessage("");

        String adventureName = this.ui.adventureNaming(
                "-> Name your adventure: ");

        boolean alreadyExist = this.adventureManager.alreadyExist(
            adventureName);

        if(adventureName.equals("") || alreadyExist)
        {
            
            this.ui.showMessage("");
            this.ui.showMessage("Error: The name entered already exists. Try again...\n");

            run();
        }
        else
        {
            this.ui.showMessage(
                    "\nTavern keeper:" + "“You plan to undertake " + adventureName + "," + " really?”");
            this.ui.showMessage("“How long will that take?”\n");

            int encounters = this.ui.askNumberByRange(
                    "-> How many encounters do you want " + " [1..4]: ",
                    1, 4, "adventureCreate");

            if(encounters == -1)
            {
                this.ui.showMessageError("range");
                run();
            }
            else
            {
                this.ui.showMessage("");
                this.ui.showMessage(
                        "Tavern keeper: “" + encounters + " encounters?" + " That is too much for me...”\n");

                combat(encounters);

                boolean create = this.adventureManager.postAdventure(
                        adventureName, encounters);

                if(create)
                {
                    this.ui.showMessageCreateAdventure(create,
                                                       adventureName);
                }
                else
                {
                    this.ui.showMessageError("createAdventure");
                }
            }
        }
    }

    /**
     * Método para crear combates
     *
     * @param numEncounters Número de encuentros.
     */
    private void combat(int numEncounters)
    {
        this.adventureManager.createListCombat();

        for(int i = 0; i < numEncounters; i++)
        {
            this.adventureManager.createListQuantityMonster();

            int numCombat = (i + 1);

            boolean isContinue = false;
            while(!isContinue)
            {
                this.ui.showMessage("* Encounter " + numCombat + " / " + numEncounters);
                this.ui.showMessage("* Monsters in encounter");

                List<String> listMonsterSelect = this.adventureManager.listMonsterSelect();

                this.ui.listMonsterSelect(listMonsterSelect);
                isContinue = optionMonster();
            }


            this.adventureManager.addCombat(numCombat);
        }
    }

    /**
     * Método para añadir monstruos en los combates
     */
    private void addMonster()
    {
        // Listar todos los monsters
        this.ui.showMessage("");
        List<String> listMonster = this.monsterManager.listMonster();
        int countMonster = this.ui.listAndCountMonster(listMonster);

        int choice = this.ui.askNumberByRange(
                "\nChoose a monster to add [1.." + countMonster + "]: ",
                1, countMonster, "addMonster");

        String name = this.monsterManager.selectMonster(choice);

        int quantity = this.ui.askForInteger("-> How many " + name + "(s) do you want to add: ");

        this.adventureManager.addQuantityMonster(quantity, name);

        this.ui.showMessage("");
    }

    /**
     * Método para eliminar monstruos de los combates
     */
    private void removeMonster()
    {
        int choice = this.ui.askForInteger(
                "-> Which monster do you want to delete: ");

        String removeMonster = this.adventureManager.removeMonster(
                choice);

        this.ui.showMessageRemoveMonster(removeMonster);
    }

    /**
     * Método que inicializa jugar una aventura
     */
    private void player()
    {
        List<String> adventureNames = this.adventureManager.getAdventuresName();
        if(adventureNames != null && adventureNames.size() > 0)
        {
            this.askForAdventureToPlay();
            this.startPlay();
        }
        else
        {
            this.ui.showMessage("There are no adventures to play...");
        }
    }

    /**
     * Método que pide la aventura a jugar
     */
    private void askForAdventureToPlay()
    {
        List<String> adventureNames = this.adventureManager.getAdventuresName();

        int numberOfAdventures = adventureNames.size();

        this.ui.showAdventuresName(adventureNames);

        int choice = this.ui.askNumberByRange(
                "-> Choose an adventure: ", 1, numberOfAdventures,
                "adventureName");

        this.adventureManager.setAdventureToPlay(choice);
        String adventureName = this.adventureManager.getAdventureToPlay();


        this.ui.showMessagePlayer("select", adventureName, 0, 0);

        this.addCharacterToAdventurePlay();
    }

    /**
     * Añadir los jugadores a la aventura
     */
    private void addCharacterToAdventurePlay()
    {
        int numberOfCharactersToPlay = this.ui.askNumberByRange(
                "-> Choose a number of characters [3..5]: ", 3, 5,
                "addCharacterToAdventure");

        this.characterManager.createCharactersNameToPlay();
        this.characterManager.startEmptyList(numberOfCharactersToPlay);

        this.ui.showMessagePlayer("choose", "",
            numberOfCharactersToPlay, 0);

        for(int i = 0; i <= numberOfCharactersToPlay; i++)
        {
            this.listCharactersAvailableToPlay(i, numberOfCharactersToPlay);

            boolean isSetCNameToPlay;

            if(i < numberOfCharactersToPlay)
            {
                do
                {
                    String characterName = this.listCharactersAndSelectName(i);

                    isSetCNameToPlay = this.characterManager.setCharactersNameToPlay(
                            i, characterName);

                    if(!isSetCNameToPlay)
                    {
                        this.ui.showMessageError("isSetCNameToPlay");
                    }
                }
                while(!isSetCNameToPlay);
            }
        }
    }

    /**
     * Método que lista los personajes que pueden jugar una aventura.
     *
     * @param playerCount Número de jugadores.
     * @param numberOfCharactersToPlay Número de personajes a jugar.
     */
    private void listCharactersAvailableToPlay(int playerCount, int numberOfCharactersToPlay)
    {
        List<String> charactersNameToPlayer = this.characterManager.getCharactersNameToPlay();

        this.ui.showMessagePlayer("yourParty", "",
            numberOfCharactersToPlay,
            playerCount);

        this.ui.listCharactersNameToPlayer(charactersNameToPlayer);

    }

    /**
     * Método para escoger los personajes dentro de una aventura
     *
     * @param playerCount Número de jugadores.
     * @return Nombre del personaje.
     */
    private String listCharactersAndSelectName(int playerCount)
    {
        List<String> charactersName = this.characterManager.getCharactersName();
        int totalNameList = charactersName.size();

        this.ui.showMessagePlayer("availableCharacters", "", 0, 0);

        this.ui.listCharacterName("listCharactersToPlay", charactersName);

        String message = "\n-> Choose character " + (playerCount + 1) + " in your party: ";

        int choiceCharacter = 
            this.ui.askNumberByRange(
                message, 1, totalNameList, "");

        return this.characterManager.infoCharacterByIndex(
            choiceCharacter - 1, "characterName");
    }

    /**
     * Método que añade los personajes a jugar en la aventura.
     */
    private void startPlay()
    {
        String adventureName = this.adventureManager.getAdventureToPlay();

        this.ui.showMessagePlayer("startPlay", adventureName, 0, 0);

        List<String> characterNames = this.characterManager.getCharactersNameToPlay();

        // Poner el nivel de vida
        this.characterManager.startLifePoints(characterNames);
        
        this.runAndListCombats();
    }

    /**
     * Método que muestra la información del combate
     */
    private void runAndListCombats()
    {
        int numCombats = this.adventureManager.getNumCombats();
        String nameAdventure = this.adventureManager.getAdventureToPlay();

        // Recorrer los combates que hay dentro de la aventura.
        if(numCombats != -1)
        {
            for(int i = 0; i < numCombats; i++)
            {
                List<String> listMonsterInfo = 
                    this.adventureManager.getMonstersInfo(i);
                
                this.ui.showCombatMonsterInfo(listMonsterInfo, i);
                
                this.preparation();

                this.startCombatStage(i, numCombats);
                
                if(i == numCombats-1)
                {
                    this.ui.showFinalAdventure(nameAdventure);
                }
            }
        }
        else
        {
            this.ui.showMessage("No hay combates.....");
        }
    }

    /**
     * Método principal de la fase de preparación
     */
    private void preparation()
    {
        this.ui.showPreparation();
        
        List<String> characterNames = this.characterManager.getCharactersNameToPlay();
        String[] existChampionOrClericOrPaladiOrmag = this.characterManager.incrementsInPreparation();
        
        this.ui.showSelfMotivation(characterNames, existChampionOrClericOrPaladiOrmag);
        
        this.createAndListInitiative();
    }

    /**
     * Método que crea y muestra por pantalla los 
     * personajes y su iniciativa por cada ronda
     * de un combate
     */
    private void createAndListInitiative()
    {
        this.adventureManager.createInitiative();
        
        List<String> characterRollingInitiative = 
            this.characterManager.rollingInitiative();
        List<String> monsterRollingInitiative =
            this.adventureManager.rollingInitiative();

        this.ui.showRollingInitiative(
            characterRollingInitiative, monsterRollingInitiative);
    }

    /**
     * Método que inicializa el combate
     * y muestra por pantalla la vida de los personajes
     */
    private void startCombatStage(int i, int numCombats)
    {
        this.ui.showCombatStage();

        this.characterManager.restartCountDeadCharacters();

        this.monsterManager.newDeadMonsters();

        this.combatFight(i, numCombats);
    }

    /**
     * Método para cada ronda dentro de un combate
     */
    private void combatFight(int i, int numCombats)
    {
        int winOrLoss = 0;
        int round = 0;

        List<String> listByInitiative = 
            this.ui.getListRollingInitiative();

        while(true)
        {
            round++;

            List<String> listCharactersByLife =
                this.characterManager.characterListByLife();
            this.ui.showPartyInfoInCombat(listCharactersByLife, round);

            for(String initiative : listByInitiative)
            {
                if(this.adventureManager.getMonstersOfCombat().size() == 0
                    || this.characterManager.getCharactersInCombat().size() ==
                        this.characterManager.getCountDeadCharacters())
                {
                    if(this.adventureManager.getMonstersOfCombat().size() == 0)
                    {
                        this.ui.showMessage("\nEnd of round " + round + ".");
                        this.ui.showMessage("All enemies are defeated.\n");

                        if(i != numCombats - 1)
                        {
                            this.shortRestStage();
                        }
                        winOrLoss = 1;
                        break;
                    }
                    else
                    {
                        winOrLoss = 1;
                        this.ui.showMessageTpu();
                        this.run();
                    }
                }
                else
                {
                    String[] characterNameAndDamageTypeAndClass = this.characterManager.combatFight(initiative);

                    if(!"".equals(characterNameAndDamageTypeAndClass[0]))
                    {
                        this.charactersFight(
                            characterNameAndDamageTypeAndClass[0],
                            characterNameAndDamageTypeAndClass[1],
                            characterNameAndDamageTypeAndClass[2]);
                    }
                    
                    String[] monsterNameAndDamageType = this.monsterManager.combatFight(initiative);
                    if(!"".equals(monsterNameAndDamageType[0]))
                    {
                        this.monstersFight(monsterNameAndDamageType[0], monsterNameAndDamageType[1]);
                    }
                }
            }

            if(winOrLoss != 1)
            {
                this.ui.showMessage("\nEnd of round " + round + ".\n");
            }
            else
            {
                break;
            }
        }
    }

    /**
     * Método en el que los personajes atacan a un monstruo
     * en el combate
     *
     * @param characterName Nombre del personaje.
     */
    private void charactersFight(String characterName, String characterDamageType, String characterClass)
    {
        int attack = this.characterManager.getAttack();
        int swordSlash = this.characterManager.getSwordSlash();

        String[] monsterNameAndHit = this.monsterManager.attackCharacterToMonster(swordSlash,
            characterDamageType, characterClass, attack);
        boolean isDies = this.monsterManager.isDies();

        String deadMonstersWhenMag = new String();

        if(characterClass.equals("Magician"))
        {
            if(!monsterNameAndHit[3].equals("nada"))
            {
                deadMonstersWhenMag = monsterNameAndHit[3];
            }
        }
        else
        {
            deadMonstersWhenMag = "nada";
        }

        String allCharactersName = this.characterManager.getCharactersInCombatToPrint();

        this.ui.showMessagesOfFightingCharacter(characterName, monsterNameAndHit[0], attack, monsterNameAndHit[1], isDies, characterClass,
                            monsterNameAndHit[2], allCharactersName, deadMonstersWhenMag);
    }
    
    /**
     * Método en el que los monstruos atacan a un personaje 
     * en el combate
     *
     * @param monsterName Nombre del monstruo.
     */
    private void monstersFight(String monsterName, String monsterDamageType)
    {
        int attack = this.monsterManager.getAttack();
        int points = this.monsterManager.getHit();

        List<String> nameCharacters = this.characterManager.attackMonsterToCharacter(points);
        List<String> charactersDeadName = this.characterManager.getCharactersDeadName();
        boolean isDies = this.characterManager.isDies();

        this.ui.showMessagesOfFightingMonster(monsterName, nameCharacters,
            charactersDeadName, attack, points, isDies, monsterDamageType);
    }

    /**
     * Método para iniciar la etapa de descanso
     */
    private void shortRestStage()
    {
        this.ui.showShortRestStage();
        int totalSumExperience =
            this.monsterManager.totalSumExperienceToDeadMonster();

        this.characterManager.addNewExperienceToCharacters(totalSumExperience);

        List<String> increaseCharacterLevel = this.characterManager.increaseCharacterLevel(totalSumExperience);
        
        this.ui.showNewCharactersXp(increaseCharacterLevel);
        
        List<String> bandageTimeList = 
            this.characterManager.bandageTimeAndReturnsTheResult();
        this.ui.showBandageTimeList(bandageTimeList);
    }
}