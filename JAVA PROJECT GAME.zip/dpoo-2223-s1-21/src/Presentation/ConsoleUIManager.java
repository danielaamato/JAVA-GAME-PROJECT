package Presentation;

import java.util.*;

public class ConsoleUIManager
{
    private final Scanner scanner;
    private final Menu menu;
    private final String ERROR_WRONG_OPTION = "\nError, the entered option is not a valid option! Try again...\n";
    private int countInvalidRangeEncounter = 0;
    private List<String> listRollingInitiative;

    /**
     * Constructor de la UI
     */
    public ConsoleUIManager()
    {
        this.menu = new Menu();
        this.scanner = new Scanner(System.in);
    }

    /**
     * Método que devuelve cantidad de intentos
     *
     * @return cantidad de intentos
     */
    private int getCountIRE()
    {
        return countInvalidRangeEncounter;
    }

    /**
     * Método que resetea los intentos
     */
    private void resetCountIRE()
    {
        this.countInvalidRangeEncounter = 0;
    }

    /**
     * Método que incrementa los intentos
     */
    private void setCountIRE()
    {
        this.countInvalidRangeEncounter++;
    }

    /**
     * Método para llamar la clase Menu
     *
     * @return Returns any method of the Menu class.
     */
    private Menu getMenu()
    {
        return menu;
    }

    /**
     * Método para escoger entre local o nube
     *
     * @return un elemento en la enumeración {@link MenuOptions} que representa la opción elegida por el usuario.
     */
    public MenuOptions showMenuData()
    {
        do
        {
            this.menu.chooseData();
            try
            {
                String option = scanner.nextLine();

                switch(option)
                {
                    case "1" ->
                    {
                        return MenuOptions.LOCAL_DATA;
                    }
                    case "2" ->
                    {
                        return MenuOptions.CLOUD_DATA;
                    }
                    default -> this.showMessage(ERROR_WRONG_OPTION);
                }
            }
            catch(NumberFormatException e)
            {
                this.showMessage(ERROR_WRONG_OPTION);
            }
        }
        while(true);
    }

    /**
     * Método que muestra el menu principal al usuario
     *
     * @return un elemento en la enumeración {@link MenuOptions} que representa la opción elegida por el usuario.
     */
    public MenuOptions showMenu(int sizeCharacter)
    {
        do
        {
            menu.showMenu(sizeCharacter);
            try
            {
                String option = scanner.nextLine();

                switch(option)
                {
                    case "1" ->
                    {
                        return MenuOptions.CREATE_CHARACTER;
                    }
                    case "2" ->
                    {
                        return MenuOptions.LIST_CHARACTERS;
                    }
                    case "3" ->
                    {
                        return MenuOptions.CREATE_ADVENTURE;
                    }
                    case "4" ->
                    {
                        return MenuOptions.START_ADVENTURE;
                    }
                    case "5" ->
                    {
                        return MenuOptions.EXIT;
                    }
                    default -> this.showMessage(ERROR_WRONG_OPTION);
                }
            }
            catch(NumberFormatException e)
            {
                this.showMessage(ERROR_WRONG_OPTION);
            }
        }
        while(true);
    }

    /**
     * Método para mostrar mensajes por pantalla, con salto de línea
     *
     * @param message Mensaje a mostrar.
     */
    public void showMessage(String message)
    {
        this.getMenu().showMessage(message);
    }

    /**
     * Método para mostrar mensajes por pantalla, sin salto de línea
     *
     * @param message Mensaje a mostrar.
     */
    private void showMessageAsk(String message)
    {
        this.getMenu().showMessageAsk(message);
    }

    /**
     * Método que muestra un mensaje de error.
     * 
     * @param option Tipo de mensaje a mostrar.
     */
    public void showMessageError(String option)
    {
        switch(option)
        {
            case "name" ->
                    this.showMessage("Sorry that's not the valid name..." 
                        + " Try again.\n");
            case "createCharacter" -> 
                this.showMessage("Error: Failed to save character.");
            case "createAdventure" ->
                this.showMessage("Error: Failed to save adventure.");
            case "range" ->
                this.showMessage("Error: The number you entered is"
                    + " not within the range. Try again...");
            case "askForAdventureToPlay" ->
                this.showMessage(
                    "Sorry, there are no adventures available, " 
                        + "create one and try again.\n");
            case "isSetCNameToPlay" ->
                this.showMessage("Error: This character is already added,"
                    + " choose another one.");
        }
    }

    /**
     * Método que muestra los mensajes del Load.
     * 
     * @param option Opción para saber que mensaje mostrar.
     */
    public void showMessageLoad(int option)
    {
        switch(option)
        {
            case 1 -> this.showMessage("Loading data..."); 
            case 2 -> this.showMessage("Data was successfully loaded.\n"); 
            case 3 -> 
            {
                this.showMessage("Couldn’t connect to the remote server.");
                this.showMessage("Reverting to local data.");
                this.showMessage("");
            }
        }
    }

    /**
     * Método que muestra el mensaje de "Closing game".
     */
    public void showMessageClosing()
    {
        this.showMessage("Closing game...");
    }

    /**
     * Método que pide al usuario un número entero válido
     *
     * @param message Mensaje a mostrar.
     * @return Entero.
     */
    public int askForInteger(String message)
    {
        while(true)
        {
            try
            {
                this.showMessageAsk(message);
                return scanner.nextInt();
            }
            catch(InputMismatchException e)
            {
                this.showMessage(
                    "That's not a valid integer, try again!");
            }
            finally
            {
                scanner.nextLine();
            }
        }
    }

    /**
     * Método que pide al usuario un texto
     *
     * @param message Mensaje a mostrar.
     * @return String.
     */
    public String askForString(String message)
    {
        showMessageAsk(message);
        return scanner.nextLine();
    }

    /**
     * Método que controla la cantidad de intentos de crear una aventura.
     *
     * @param message Mensaje a mostrar.
     * @param option Opción para saber que mensaje mostrar.
     * @return Entero.
     */
    private int askForInteger(String message, String option)
    {
        while(true)
        {
            try
            {
                this.showMessageAsk(message);
                return scanner.nextInt();
            }
            catch(InputMismatchException e)
            {
                if(option.equals("adventureCreate")
                    && this.getCountIRE() == 2)
                {
                    this.resetCountIRE();
                    return  -1;
                }
                else
                {
                    if(option.equals("adventureCreate"))
                    {
                        this.setCountIRE();
                    }
                    this.showMessage(
                        "Sorry you have entered a wrong number... "
                          + " Try again.");
                }
            }
            finally
            {
                scanner.nextLine();
            }
        }
    }
    
    /**
     * Método que carga los JSON
     */
    public void showBeginning()
    {
        this.getMenu().chargingJson();
    }

    /**
     * Método que pide enteros dentro de un rango
     *
     * @param message Mensaje a mostrar.
     * @param numMin Número mínimo.
     * @param numMax Número máximo.
     * @param option Opción para saber que mensaje mostrar.
     * @return Entero.
     */
    public int askNumberByRange(
        String message, int numMin, int numMax, String option)
    {
        int number;
        boolean exists;
        
        do
        {
            number = this.askForInteger(message, option);

            if(number >= numMin && number <= numMax && number != -1)
            {
                if(option.equals("characterList") && number == numMin)
                {
                    break;
                }
                else
                {
                    exists = true;
                }
                
                
            }
            else
            {
                this.showMessage("");
                this.showMessage(
                    "Sorry you have entered a wrong number... "
                    + " Try again.\n");

                if(option.equals("adventureCreate")
                    && this.getCountIRE() == 2
                    || number == -1)
                {
                    this.resetCountIRE();
                    number = -1;
                    exists = true;
                }
                else
                {
                    if(option.equals("adventureCreate"))
                    {
                        this.setCountIRE();
                    }
                    exists = false;
                }
            }
        }
        while(!exists);
        
        return number;
    }

    /**
     * Método que pide al usuario el nombre de un personaje
     *
     * @param message Mensaje a mostrar.
     * @return nombre del personaje
     */
    public String askNameCharacter(String message)
    {
        String name = askForString(message);
        return this.getMenu().askNameCharacter(name);
    }

    /**
     * Método que pide al usuario el nombre de un jugador.
     *
     * @param message Mensaje a mostrar.
     * @return nombre del jugador
     */
    public String askNamePlayer(String message)
    {
        String name = askForString(message);
        return this.getMenu().askNamePlayer(name);
    }

    /**
     * Método para mostrar los mensajes a la hora de crear un personaje.
     * 
     * @param option Opción para saber que mensaje mostrar.
     * @param characterName Nombre del personaje.
     * @param characterLevel Nival del personaje.
     */
    public void showMessageCharacterCreation(int option, String characterName, int characterLevel)
    {
        switch(option)
        {
            case 1 ->
            {
                this.showMessage("Tavern keeper: “Oh, so you are new to this land.”");
                this.showMessage("“What’s your name?”\n");
            }
            case 2 -> this.showMessage(
                "Sorry, you have entered an existing"
                + " character name or you have entered an empty name! Try again...\n");
            case 3 ->
            {
                this.showMessage("\nTavern keeper: Hello, " + characterName + ", be welcome.");
                this.showMessage("And now, if I may break the fourth wall, who is your Player?\n");
            }
            case 4 ->
            {
                this.showMessage(
                        "\nTavern keeper: Oh, so you are level " + characterLevel + "!");
                this.showMessage(
                        "Great, let me get a closer look at you...\n");
                this.showMessage("Generating your stats...\n");
            }
            case 5 -> this.showMessage("\nYour stats are:");
            case 6 ->
            {
                this.showMessage("Tavern keeper: “Looking good!”");
                this.showMessage("“And, lastly, ?”\n");
            }
        }
    }

    /**
     * Método para mostrar los mensajes a la hora de listar los personajes.
     * 
     * @param option Opción para saber que mensaje mostrar.
     */
    public void showMessageCharacterList(int option)
    {
        switch(option)
        {
            case 1 ->
            {
                this.showMessage("\nTavern keeper: “Lads! They want to see you!”");
                this.showMessage("“Who piques your interest?”");
            }
            case 2 -> this.showMessage("\nYou watch as all adventurers get up from their chairs and approach you.\n");
            case 3 -> this.showMessage("\nYou watch as some adventurers get up from their chairs and approach you.\n");
            case 4 -> this.showMessage("\nSorry, that player does not exist.\n");
            case 5 -> this.showMessage("Character list is null.");
        }
    }

    /**
     * Método para mostrar los mensajes a la hora de eliminar un personaje.
     */
    public void showMessageCharacterDelete()
    {
        this.showMessage("[Enter name to delete, or press enter to cancel]");
    }

    /**
     * Método que muestra los personajes al usuario
     *
     * @param listName Lista de nombres de personajes.
     */
    public void listCharacterName(String option, List<String> listName)
    {
        int cont = 0;
        for(String name : listName)
        {
            cont++;
            this.showMessage("\t" + cont + ". " + name);
        }
        if(option.equals("listCharacters"))
        {
            this.showMessage("");
            this.showMessage("\t0. Back");
        }
    }

    /**
     * Método que muestra información de un personaje
     *
     * @param infoCharacter Información del personaje.
     * @param characterName Nombre del personaje.
     */
    public void showInfoCharacter(String infoCharacter,
        String characterName)
    {
        if(!infoCharacter.equals(""))
        {
            showMessage("\nTavern keeper: “Hey " + characterName
                                + " get here; the boss wants to see you!”");

            showMessage(infoCharacter);
            showMessage("");
        }
    }

    /**
     * Método que confirma al usuario la creación de un personaje
     *
     * @param create True si se ha creado el personaje, false en caso contrario.
     */
    public void showMessageCreateAdventure(boolean create, String adventureName)
    {
        if(create)
        {
            showMessage("Tavern keeper:"
                + " “Great plan lad! I hope you won’t die!”");
            showMessage("\nThe new adventure "
                + adventureName + " has been created.\n");
        }
        else
        {
            showMessage("Error: Problem creating adventure.");
        }
    }

    /**
     * Método que muestra estadísticas generadas por pantalla
     *
     * @param stat Nombre de la estadística.
     * @param dice Dados lanzados.
     */
    public void showGenerateStat(String stat, int[] dice)
    {
        int dice1 = dice[0];
        int dice2 = dice[1];
        int sumDice = dice[2];

        showMessage(stat + ": You rolled " + sumDice
                            + " (" + dice1 + " and "+ dice2 + ").");
    }

    /**
     * Método que muestra el resultado de los dados
     *
     * @param string Nombre de la estadística.
     * @param value Valor de la estadística.
     */
    public void showResultOfDice(String string, int value)
    {
        showMessage("\t - " + string + ": " + value);
    }

    /**
     * Método que confirma creación de un personaje
     *
     * @param isCreate True si se ha creado el personaje, false en caso contrario.
     * @param characterName Nombre del personaje.
     */
    public void showMessageCreateCharacter(
        boolean isCreate, String characterName, String postedCharacterClass)
    {
        if(isCreate)
        {
            this.showMessage("");
            this.showMessage("Tavern keeper: “Any decent party needs one of those.”");
            this.showMessage("“I guess that means you’re a " + postedCharacterClass + " by now, nice!”");

            this.showMessage("\nThe new character "
                + characterName + " has been created.\n");
        }
        else
        {
            this.showMessageError("createCharacter");
        }
    }

    /**
     * Método que pide al usuario el nivel inicial de un personaje
     *
     * @return entero
     */
    public int askCharacterLevel()
    {
        this.showMessage(
                "\nTavern keeper: I see, I see...");
        this.showMessage(
                "Now, are you an experienced adventurer?\n");

        return this.askNumberByRange(
                "-> Enter the character's level" + " [1..10]: ",
                1, 10, "characterCreation");
    }

    /**
     * Método que pide la clase del personaje
     *
     * @return String.
     */
    public String askForCharacterClass()
    {
        do
        {
            String characterClass = this.askForString("-> Enter the character’s initial class [Adventurer, Cleric, Mage]: ");

            if(characterClass.equals("Adventurer") || characterClass.equals("Cleric") || characterClass.equals("Mage"))
            {
                return characterClass;
            }
            else
            {
                this.showMessage("That's not a valid character class, try again...\n");
            }
        }
        while(true);
    }

    /**
     * Método que confirma la eliminación de personaje
     *
     * @param nameCharacter Nombre del personaje.
     */
    public void showMessageConfirmDelete(String nameCharacter)
    {
        this.showMessage("\nTavern keeper: “I’m sorry kiddo,"
                                 + " but you have to leave.”");
        this.showMessage(
                "\nCharacter " + nameCharacter + " left the Guild.");
    }

    /**
     * Método que pide al usuario el nombre para una aventura
     *
     * @param message Mensaje a mostrar.
     * @return nombre de la aventura
     */
    public String adventureNaming(String message)
    {
        String name = this.askForString(message);

        if(name.equals(""))
        {
            return "";
        }
        else
        {
            return name;
        }
    }

    /**
     * Método que muestra todas las aventuras por pantalla
     *
     * @param adventuresName Lista de nombres de aventuras.
     */
    public void showAdventuresName(List<String> adventuresName)
    {
        int count = 0;
        this.showMessage("");
        this.showMessage("Tavern keeper: “So, you are looking to go"
            + " on an adventure?”");
        this.showMessage("“Where do you fancy going?”\n");

        this.showMessage("Available adventures:");

        for(String adventureName : adventuresName)
        {
            count++;
            this.showMessage("\t" + count + ". " + adventureName);
        }
        this.showMessage("");
    }

    /**
     * Método que muestra el menú de monstruos al usuario
     *
     * @return un elemento en la enumeración {@link MenuOptions}
     *      que representa la opción elegida por el usuario.
     */
    public MenuOptions showMenuMonster()
    {
        do
        {
            menu.showMenuMonster();
            try
            {
                String option = scanner.nextLine();

                switch(option)
                {
                    case "1" ->
                    {
                        return MenuOptions.ADD_MONSTER;
                    }
                    case "2" ->
                    {
                        return MenuOptions.REMOVE_MONSTER;
                    }
                    case "3" ->
                    {
                        return MenuOptions.CONTINUE;
                    }
                    default -> this.showMessage(ERROR_WRONG_OPTION);
                }
            }
            catch(NumberFormatException e)
            {
                this.showMessage(ERROR_WRONG_OPTION);
            }
        }
        while(true);
    }

    /**
     * Método que lista monstruos de un combate
     *
     * @param listMonsterSelect Lista de monstruos.
     */
    public void listMonsterSelect(List<String> listMonsterSelect)
    {
        if(listMonsterSelect.size() != 0)
        {
            int count = 0;
            for(String nameAndQuantity : listMonsterSelect)
            {
                count++;
                this.showMessage("\t" + count 
                    + ". " + nameAndQuantity);
            }
        }
        else
        {
            this.showMessage("\t# Empty");
        }
        this.showMessage("");
    }

    /**
     * Método que cuenta los monstruos de un combate
     *
     * @param monsterList Lista de monstruos.
     * @return entero
     */
    public int listAndCountMonster(List<String> monsterList)
    {
        int count = 0;
        for(String monster : monsterList)
        {
            count++;
            this.showMessage(count + ". " + monster);
        }
        return count;
    }

    /**
     * Método que muestra error a la hora de eliminar un monstruo
     *
     * @param message Mensaje a mostrar.
     */
    public void showMessageRemoveMonster(String message)
    {
        this.showMessage("");
        if("Error".equals(message))
        {
            this.showMessage("Error: 0 Monsters to remove.");
        }
        else
        {
            this.showMessage(message 
                + " were removed from the encounter.");
        }
        this.showMessage("");
    }

    /**
     * Método que muestra mensajes sobre la nueva aventura por pantalla
     *
     * @param adventureName Nombre de la aventura.
     */
    public void showMessagePlayer(String option, String adventureName, 
        int numberOfCharactersToPlay, int playerCount)
    {
        switch(option)
        {
            case "select" -> 
            {
                this.showMessage(
                        "\nTavern keeper: “" + adventureName + " it is!”");
                this.showMessage("“And how many people shall join you?”\n");
            }
            case "choose" ->
            {
                this.showMessage("\nTavern keeper: “Great, "
                    + numberOfCharactersToPlay + " it is.”");
                this.showMessage("“Who among these lads shall" 
                    + "join you?”");
            }
            case "yourParty" ->
            {
                this.showMessage("\n------------------------------");
                this.showMessage("Your party (" + playerCount
                    + " / " + numberOfCharactersToPlay + ")");
            }
            case "availableCharacters" ->
            {
                this.showMessage("------------------------------");
                this.showMessage("Available characters:");
            }
            case "startPlay" ->
            {
                this.showMessage("------------------------------\n");
                this.showMessage("Tavern keeper: “Great, "
                    + "good luck on your adventure lads!”\n");
                
                this.showMessage("The “" + adventureName
                    + "” will start soon...\n");
            }
        }
    }

    /**
     * Método que muestra los personajes que pueden jugar en una aventura
     *
     * @param charactersNameToPlayer Lista de nombres de personajes.
     */
    public void listCharactersNameToPlayer(
        List<String> charactersNameToPlayer)
    {
        for(int i = 0; i < charactersNameToPlayer.size(); i++)
        {
            this.showMessage("\t" + (i+1)
                + ". " + charactersNameToPlayer.get(i));
        }
    }

    /**
     * Método que muestra la información de un combate
     *
     * @param listMonsterInfo Lista de monstruos.
     * @param combat Numero de combate.
     */
    public void showCombatMonsterInfo(List<String> listMonsterInfo, int combat)
    {
        this.showMessage("---------------------");
        this.showMessage("Starting Encounter " + (combat+1) + ":");

        for(String monster : listMonsterInfo)
        {
            this.showMessage("\t- " + monster);
        }

        this.showMessage("---------------------");
    }

    /**
     * Método que muestra inicialización de la etapa de preparacion
     */
    public void showPreparation()
    {
        this.showMessage("---------------------");
        this.showMessage("*** Preparation stage ***");
        this.showMessage("---------------------");
    }

    /**
     * Método que muestra el incremento de atributos
     * en los personajes en la etapa de preparacion
     *
     * @param characterNames Lista de nombres de personajes.
     */
    public void showSelfMotivation(List<String> characterNames, String[] championOrClericOrPaladi)
    {
        for(String characterName : characterNames)
        {
            if(characterName.equals(championOrClericOrPaladi[0]))
            {
                this.showMessage(characterName + " uses Motivational speech. " +
                                         "Everyone’s Spirit increases in +1.");
            }
            else if(characterName.equals(championOrClericOrPaladi[1]))
            {
                this.showMessage(characterName + " uses Prayer of good luck. " +
                                         "Everyone’s Mind increases in +1.");
            }
            else if(characterName.equals(championOrClericOrPaladi[2]))
            {
                this.showMessage(characterName + " uses Blessing of good luck. Everyone's Mind increases" +
                                         " in +" + championOrClericOrPaladi[3] + ".");
            }
            else if(characterName.equals(championOrClericOrPaladi[4]))
            {
                this.showMessage(characterName + " uses Mage shield. Shield recharges to " + championOrClericOrPaladi[5] + ".");
            }
            else
            {
                this.showMessage(
                        characterName + " uses Self-Motivated. Their Spirit increases in +1.");
            }
        }
    }

    /**
     * Método que muestra la generación de las iniciativas
     *
     * @param characterRollingInitiative Lista de personajes.
     * @param monsterRollingInitiative Lista de monstruos.
     */
    public void showRollingInitiative(
        List<String> characterRollingInitiative,
        List<String> monsterRollingInitiative)
    {
        this.showMessage("\nRolling initiative...");

        List<String> list = new ArrayList<>();
        list.addAll(characterRollingInitiative);
        list.addAll(monsterRollingInitiative);
        sort(list);
        this.listRollingInitiative = new ArrayList<>(list);

        for(String s : list)
        {
            this.showMessage("\t- " + s);
        }
        this.showMessage("");
    }

    /**
     * Método que devuelve la lista de iniciativas
     *
     * @return listRollingInitiative Lista de iniciativas.
     */
    public List<String> getListRollingInitiative()
    {
        return this.listRollingInitiative;
    }

    /**
     * Método que ordena la lista de iniciativa de mayor a menor
     * @param list Lista de iniciativas.
     */
    private void sort(List<String> list)
    {
        list.sort(new Comparator<String>()
        {
            public int compare(String o1, String o2)
            {
                return extractInt(o2) - extractInt(o1);
            }

            int extractInt(String s)
            {
                String num = s.replaceAll("\\D", "");
                return num.isEmpty() ? 0 : Integer.parseInt(num);
            }
        });
    }

    /**
     * Método para iniciar por pantalla un combate
     */
    public void showCombatStage()
    {
        this.showMessage("---------------------");
        this.showMessage("*** Combat stage ***");
        this.showMessage("---------------------");
    }

    /**
     * Método para mostrar la vida de los
     * personajes en una determinada ronda
     *
     * @param listOfCharactersByLife Lista de personajes.
     */
    public void showPartyInfoInCombat(List<String> listOfCharactersByLife, int round)
    {
        this.showMessage("Round " + round + ":");
        this.showMessage("Party:");

        for(String s: listOfCharactersByLife)
        {
            this.showMessage("\t- " + s + " hit points");
        }
    }

    /**
     * Método que muestra por pantalla cuando un personaje ataca a un monstruo
     *
     * @param characterName Nombre del personaje.
     * @param nameMonster Nombre del monstruo.
     * @param attack Ataque del personaje.
     * @param hitPoints Vida del monstruo.
     * @param isDies Si el monstruo muere.
     * @param characterClass Clase del personaje.
     */
    public void showMessagesOfFightingCharacter(
        String characterName, String nameMonster,
        int attack, String hitPoints, boolean isDies, 
        String characterClass, 
        String characterCureWhenCleric,
        String allCharactersName, String deadMonstersWhenMag)
    {
        String hitPrint = new String();
        boolean isClericCure = false;
        boolean isPaladiCure = false;

        if(characterCureWhenCleric.equals("Fireball") && characterClass.equals("Magician"))
        {
            hitPrint = "with Fireball.";
        }
        else if(characterClass.equals("Magician"))
        {
            hitPrint = "with Arcane missile.";
        }

        if(characterClass.equals("Cleric"))
        {
            if(nameMonster.equals("Curacion"))
            {
                this.showMessageAsk("\n" + characterName + " uses Prayer of healing. Heals "+ hitPoints
                                         + " hit points to " + characterCureWhenCleric + ".");
                isClericCure = true;
            }
        }

        if(characterClass.equals("Paladi"))
        {
            if(nameMonster.equals("Curacion"))
            {
                this.showMessageAsk("\n" + characterName + " uses Prayer of mass healing. Heals "+ hitPoints
                                         + " hit points to " + allCharactersName);
                isPaladiCure = true;
            }
        }

        if(!isClericCure)
        {
            if(characterClass.equals("Cleric"))
            {
                hitPrint = "with Not on my watch.";
            }
        }

        if(!isPaladiCure)
        {
            if(characterClass.equals("Paladi"))
            {
                hitPrint = "with Never on my watch.";
            }
        }

        if(characterClass.equals("Adventurer"))
        {
            hitPrint = "with sword slash.";
        }

        if(characterClass.equals("Warrior"))
        {
            hitPrint = "with Improved sword slash.";
        }

        if(characterClass.equals("Champion"))
        {
            hitPrint = "with Improved sword slash.";
        }

        this.showMessage("");

        if(!isClericCure && characterClass.equals("Cleric"))
        {
            this.showMessage(
                        characterName + " attacks " + nameMonster + " " + hitPrint);
        }
        else if(!isPaladiCure && characterClass.equals("Paladi"))
        {
            this.showMessage(characterName + " attacks " + nameMonster + " " + hitPrint);
        }
        else
        {
            if(!isPaladiCure && !isClericCure)
            {
                this.showMessage(
                        characterName + " attacks " + nameMonster + " " + hitPrint);
            }
        }

        if(attack > 1 && attack < 10)
        {
            if(characterClass.equals("Cleric"))
            {
                if(!isClericCure)
                {
                    this.showMessage(
                            "Hits and deals " + hitPoints + " psychical damage.");
                }
            }
            else
            {
                if(characterClass.equals("Paladi"))
                {
                    if(!isPaladiCure)
                    {
                        this.showMessage(
                                "Hits and deals " + hitPoints + " psychical damage.");
                    }
                }
                else if(characterClass.equals("Magician"))
                {
                    this.showMessage(
                            "Hits and deals " + hitPoints + " magical damage.");
                }
                else
                {
                    this.showMessage(
                            "Hits and deals " + hitPoints + " physical damage.");
                }
            }
        }
        else if(attack == 10)
        {
            if(characterClass.equals("Cleric"))
            {
                if(!isClericCure)
                {
                    this.showMessage(
                            "Critical hit and deals " + hitPoints + " psychical damage.");
                }
            }
            else if(characterClass.equals("Paladi"))
            {
                if(!isPaladiCure)
                {
                    this.showMessage(
                            "Critical hit and deals " + hitPoints + " psychical damage.");
                }
            }
            else if(characterClass.equals("Magician"))
            {
                this.showMessage(
                        "Critical hit and deals " + hitPoints + " magical damage.");
            }
            else
            {
                this.showMessage(
                        "Critical hit and deals " + hitPoints + " physical damage.");
            }
        }
        else if(attack == 1)
        {
            if(characterClass.equals("Cleric"))
            {
                if(!isClericCure)
                {
                    this.showMessage(
                            "Fails and deals " + hitPoints + " psychical damage.");
                }
            }
            else if(characterClass.equals("Paladi"))
            {
                if(!isPaladiCure)
                {
                    this.showMessage(
                            "Fails and deals " + hitPoints + " psychical damage.");
                }
            }
            else if(characterClass.equals("Magician"))
            {
                this.showMessage(
                        "Fails and deals " + hitPoints + " magical damage.");
            }
            else
            {
                this.showMessage(
                        "Fails and deals " + hitPoints + " physical damage.");
            }
        }

        if(characterClass.equals("Magician"))
        {
            if(!deadMonstersWhenMag.equals("nada") && !deadMonstersWhenMag.equals(""))
            {
                this.showMessage(deadMonstersWhenMag + "dies.");
            }
        }
        else if(isDies)
        {
            if(!isClericCure && !isPaladiCure)
            {
                this.showMessage(nameMonster + " dies.");
            }
        }
    }

    /**
     * Método que muestra por pantalla cuando un monstruo ataca a un personaje
     *
     * @param monsterName Nombre del monstruo.
     * @param nameCharacters Nombre de los personajes que ataca.
     * @param charactersDeadName Nombre de los personajes que han muerto.
     * @param attack Ataque del monstruo.
     * @param points Puntos de daño del monstruo.
     * @param isDies Si el monstruo muere.
     */
    public void showMessagesOfFightingMonster(
        String monsterName, List<String> nameCharacters, List<String> charactersDeadName,
        int attack, int points, boolean isDies, String monsterDamageType)
    {
        int size = nameCharacters.size();
        this.showMessage("");

        this.showMessageAsk(monsterName + " attacks ");

        if(size == 1)
        {
            this.showMessageAsk(nameCharacters.get(0) + ".");
        }
        else
        {
            int count = 0;
            for(String nameCharacter : nameCharacters)
            {
                if(count == (size-1))
                {
                    this.showMessageAsk("and " + nameCharacter);
                }
                else
                {
                    this.showMessageAsk(nameCharacter + ", ");
                }
                count++;
            }
            this.showMessageAsk(".");
        }

        if(attack > 1 && attack < 10)
        {
            this.showMessage("");
            if(monsterDamageType.equals("Physical"))
            {
                this.showMessage(
                        "Hits and deals " + points + " physical damage.");
            }
            else if(monsterDamageType.equals("Psychical"))
            {
                this.showMessage(
                        "Hits and deals " + points + " psychical damage.");
            }
            else
            {
                this.showMessage(
                        "Hits and deals " + points + " magical damage.");
            }
        }
        else if (attack == 10) {
            this.showMessage("");
            if(monsterDamageType.equals("Physical"))
            {
                this.showMessage(
                        "Critical hit and deals " + points + " physical damage.");
            }
            else if(monsterDamageType.equals("Psychical"))
            {
                this.showMessage(
                        "Critical hit and deals " + points + " psychical damage.");
            }
            else
            {
                this.showMessage(
                        "Critical hit and deals " + points + " magical damage.");
            }
        }
        else
        {
            this.showMessage("");
            if(monsterDamageType.equals("Physical"))
            {
                this.showMessage(
                        "Fails and deals " + points + " physical damage.");
            }
            else if(monsterDamageType.equals("Psychical"))
            {
                this.showMessage(
                        "Fails and deals " + points + " psychical damage.");
            }
            else
            {
                this.showMessage(
                        "Fails and deals " + points + " magical damage.");
            }
        }

        if(isDies)
        {
            if(charactersDeadName.size() == 1)
            {
                this.showMessage(charactersDeadName.get(0) + " falls unconscious.");
            }
            else
            {
                int count = 0;
                for(String deadName : charactersDeadName)
                {
                    if(count == (charactersDeadName.size()-1))
                    {
                        this.showMessageAsk(deadName);
                    }
                    else
                    {
                        this.showMessageAsk(deadName + ", ");
                    }
                    count++;
                }
                this.showMessageAsk(" falls unconscious.");
            }
        }
    }

    /**
     * Mostramos por pantalla mensaje de Tpu.
     */
    public void showMessageTpu()
    {
        this.showMessage("");
        this.showMessage("Tavern keeper: “Lad, wake up. Yes, your party fell unconscious.”");
        this.showMessage("“Don’t worry, you are safe back at the Tavern.”\n");
    }

    /**
     * Mostramos la Short Rest Stage.
     */
    public void showShortRestStage()
    {
        this.showMessage("---------------------");
        this.showMessage("*** Short rest stage ***");
        this.showMessage("---------------------");
    }

    /**
     * Mostramos la nueva Xp de los personajes
     * @param increaseCharacterLevel Show New Characters Xp.
     */
    public void showNewCharactersXp(List<String> increaseCharacterLevel)
    {
        for(String nameCharacter : increaseCharacterLevel)
        {
            this.showMessage(nameCharacter);
        }
    }

    /**
     * Monstramos Bandage Time List.
     * @param bandageTimeList Bandage Time List.
     */
    public void showBandageTimeList(List<String> bandageTimeList)
    {
        this.showMessage("");
        for(String s : bandageTimeList)
        {
            this.showMessage(s);
        }
        this.showMessage("");
    }

    /**
     * Mensaje final de aventura.
     * @param nameAdventure Nombre de la aventura.
     */
    public void showFinalAdventure(String nameAdventure)
    {
        this.showMessage("Congratulations, your party completed “" + nameAdventure + "”");
        this.showMessage("");
    }
}