package Business.Adventure;

import Business.Monster.Monster;

public class QuantityMonster
{
    private int quantity;
    private Monster monster;

    /**
     * Constructor de Quantity Monster
     *
     * @param quantity Cantidad de un monstruo en un combate.
     * @param monster Monstruo.
     */
    public QuantityMonster(int quantity, Monster monster)
    {
        this.quantity = quantity;
        this.monster = monster;
    }

    /**
     * Método que devuelve la cantidad que hay
     * de un monstruo dentro de un combate
     *
     * @return Cantidad de un monstruo en un combate.
     */
    public int getQuantity()
    {
        return quantity;
    }

    /**
     * Método que asigna la cantidad que hay
     * de un monstruo dentro de un combate
     *
     * @param quantity Cantidad de un monstruo en un combate.
     */
    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }

    /**
     * Método que incrementa la cantidad que hay
     * de un monstruo dentro de un combate
     *
     * @param quantity Cantidad de un monstruo en un combate.
     */
    public void addQuantity(int quantity)
    {
        this.quantity = this.quantity + quantity;
    }

    /**
     * Método que devuelve un monstruo.
     *
     * @return Monstruo.
     */
    public Monster getMonster()
    {
        return monster;
    }

    /**
     * Método que asigna un monstruo
     *
     * @param monster Monstruo.
     */
    public void setMonster(Monster monster)
    {
        this.monster = monster;
    }
}