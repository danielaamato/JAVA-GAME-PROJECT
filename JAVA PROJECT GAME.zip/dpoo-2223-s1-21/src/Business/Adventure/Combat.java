package Business.Adventure;

import java.util.List;

public class Combat
{
    private int number;
    private List<QuantityMonster> monsters;

    /**
     * Constructor de combate
     *
     * @param number Número de combate.
     * @param monsters Lista de monstruos con su cantidad.
     */
    public Combat(int number, List<QuantityMonster> monsters)
    {
        this.number = number;
        this.monsters = monsters;
    }

    /**
     * Get número de combate.
     *
     * @return Número de combate.
     */
    public int getNumber()
    {
        return number;
    }

    /**
     * Set número de combate.
     *
     * @param number Número de combate.
     */
    public void setNumber(int number)
    {
        this.number = number;
    }

    /**
     * Método que devuelve la lista con la cantidad de un monstruo
     * en un combate
     *
     * @return Lista de monstruos con su cantidad.
     */
    public List<QuantityMonster> getMonsters()
    {
        return monsters;
    }

    /**
     * Set lista de monstruos con su cantidad.
     *
     * @param monsters Lista de monstruos con su cantidad.
     */
    public void setMonsters(List<QuantityMonster> monsters)
    {
        this.monsters = monsters;
    }
}