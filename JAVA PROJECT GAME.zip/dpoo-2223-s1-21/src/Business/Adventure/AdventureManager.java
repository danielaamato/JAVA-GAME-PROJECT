package Business.Adventure;

import Business.Monster.Monster;
import Business.Monster.MonsterBoss;
import Business.Monster.MonsterManager;
import Persistence.Adventure.AdventureApiDAO;
import Persistence.Adventure.AdventureDAO;
import Persistence.Adventure.AdventureJsonDAO;
import Presentation.MenuOptions;

import java.util.ArrayList;
import java.util.List;

public class AdventureManager
{
    private MonsterManager monsterManager;
    private AdventureDAO adventureDAO;
    private List<Combat> combats;
    private List<QuantityMonster> quantityMonsters;
    private List<QuantityMonster> quantityMonstersToActualCombat;
    private List<Monster> monstersToActualCombat;
    private String adventureToPlayer;

    /**
     * Constructor del Adventure Manager
     */
    public AdventureManager(MenuOptions menuOptions)
    {
        switch(menuOptions)
        {
            case LOCAL_DATA -> this.adventureDAO = new AdventureJsonDAO(); 
            case CLOUD_DATA -> this.adventureDAO = new AdventureApiDAO();
        }
    }

    /**
     * Inicializamos el monster manager
     *
     * @param monsterManager Monster Manager.
     */
    public void startMonster(MonsterManager monsterManager)
    {
        this.monsterManager = monsterManager;
    }

    /**
     * Comprobar que el fichero .josn del Adventure existe.
     *
     * @return Devuelve true si existe el fichero y false si no existe.
     */
    public boolean isExist(MenuOptions options)
    {
        boolean isExistDirectory = this.adventureDAO.isExistDirectory();
        boolean isExistFile = this.adventureDAO.isExistFile();
        switch(options)
        {
            case LOCAL_DATA ->
            {
                if(isExistDirectory)
                {
                    if(isExistFile)
                    {
                        return true;
                    }
                    else
                    {
                        return this.adventureDAO.createFile();
                    }
                }
                else
                {
                    return this.adventureDAO.createDirectory();
                }
            }
            case CLOUD_DATA ->
            {
                return isExistDirectory;
            }
        }

        System.exit(0);
        return false;
    }

    /**
     * Get lista de aventuras.
     * 
     * @return Lista de las aventuras.
     */
    public List<Adventure> getAdventures()
    {
        return this.adventureDAO.getAdventures();
    }

    /**
     * Get nombre de todas las aventuras.
     * @return Lista de nombres de las aventuras.
     */
    public List<String> getAdventuresName()
    {
        return this.adventureDAO.getAdventuresName();
    }

    /**
     * Comprobación a la hora de crear una aventura.
     * 
     * @param name Nombre de la aventura.
     * @param encounters Número de combates de la aventura.
     * @return Devuelve true si se ha creado la aventura y false si no se ha creado.
     */
    public boolean postAdventure(String name, int encounters)
    {
        Adventure adventure = new Adventure(name, encounters, this.combats);
        return this.adventureDAO.postAdventure(adventure);
    }

    /**
     * Método que verifica que no exista previamente
     * el mismo nombre de una aventura.
     * 
     * @param name Nombre de la aventura.
     * @return Devuelve true si ya existe y false si no existe.
     */
    public boolean alreadyExist(String name)
    {
        List<Adventure> adventures = getAdventures();
        if(adventures != null)
        {
            for(Adventure adventure : adventures)
            {
                if(adventure.getName()
                    .contains(
                        name.toLowerCase()) || adventure.getName()
                    .contains(
                        name.toUpperCase()) || adventure.getName()
                    .contains(name))
                {
                    return true;
                }
            }
        }
        return false;
    }

    /* ---------------------- Combat ---------------------- */

    /**
     * Método que crea la lista de combates de una aventura.
     */
    public void createListCombat()
    {
        this.combats = new ArrayList<>();
    }

    /**
     * Método que añade un nuevo combate a la
     * lista de combates de una aventura.
     * 
     * @param numCombat Número de combate.
     */
    public void addCombat(int numCombat)
    {
        Combat combat = new Combat(numCombat, this.quantityMonsters);
        this.combats.add(combat);
    }

    /* ---------------------- Quantity Monster ---------------------- */

    /**
     * Creamos una lista con los monstruos y su cantidad 
     * para cada combate.
     */
    public void createListQuantityMonster()
    {
        this.quantityMonsters = new ArrayList<>();
    }

    /**
     * Método que añade el monstruo y la cantidad suya
     * a la lista correspondiente del combate actual.
     * 
     * @param quantity Cantidad del monstruo.
     * @param nameMonster Nombre del monstruo.
     */
    public void addQuantityMonster(int quantity, String nameMonster)
    {
        Monster monster = this.monsterManager.getMonster(nameMonster);
        QuantityMonster quantityMonster = new QuantityMonster(
                quantity, monster);

        String name = quantityMonster.getMonster()
                .getName();
        String challenge = quantityMonster.getMonster()
                .getChallenge();
        boolean isExiste = false;

        if(this.quantityMonsters.size() != 0)
        {
            for(QuantityMonster qMonster : this.quantityMonsters)
            {
                String monsterName = qMonster.getMonster()
                        .getName();
                String monsterChallenge = qMonster.getMonster()
                        .getChallenge();

                if(name.equals(monsterName) && !"Boss".equals(
                        challenge))
                {
                    qMonster.addQuantity(quantity);
                    isExiste = true;
                    break;
                }

                if("Boss".equals(challenge) && challenge.equals(
                        monsterChallenge))
                {
                    isExiste = true;
                    break;
                }
            }
        }

        if(!isExiste)
        {
            if("Boss".equals(challenge))
            {
                if(quantity > 1)
                {
                    // "Sorry you can only add one monster of Boss difficulty."
                    quantityMonster.setQuantity(1);
                    this.quantityMonsters.add(quantityMonster);
                }
                else
                {
                    this.quantityMonsters.add(quantityMonster);
                }
            }
            else
            {
                this.quantityMonsters.add(quantityMonster);
            }
        }
    }

    /**
     * Método que usamos para listar 
     * los monstruos seleccionados de un combate.
     * 
     * @return Lista de Strings con los mostos selecionados.
     */
    public List<String> listMonsterSelect()
    {
        List<String> listMonsterSelect = new ArrayList<>();
        if(this.quantityMonsters.size() != 0)
        {
            for(QuantityMonster qMonster : this.quantityMonsters)
            {
                listMonsterSelect.add(buildMonsterAdventureInfo(qMonster));
            }
        }

        return listMonsterSelect;
    }

    /**
     * Método que elimina un monstruo de un combate.
     * 
     * @param choice choice
     */
    public String removeMonster(int choice)
    {
        String result;
        if(this.quantityMonsters.size() != 0 
            && choice <= this.quantityMonsters.size())
        {
            int position = choice - 1;
            QuantityMonster quantityMonster = this.quantityMonsters.remove(
                    position);

            int quantity = quantityMonster.getQuantity();
            String name = quantityMonster.getMonster()
                    .getName();

            result = buildMonsterAdventureInfo(quantity, name);
        }
        else
        {
            result = "Error";
        }

        return result;
    }

    /**
     * Método que muestra por pantalla los monstruos
     * y su cantidad dentro de un combate.
     * 
     * @param quantity cantidad.
     * @param name nombre.
     * @return String con la información del monstruo.
     */
    private String buildMonsterAdventureInfo(int quantity, String name)
    {
        return quantity + " " + name;
    }

    /**
     * Método que muestra por pantalla los monstruos
     * y su cantidad dentro de un combate.
     * 
     * @param qMonster Cantidad y el monster.
     * @return String con la información del monstruo.
     */
    private String buildMonsterAdventureInfo(QuantityMonster qMonster)
    {
        return qMonster.getMonster().getName() 
            + " (X" 
            + qMonster.getQuantity() 
            + ")";
    }

    /* ---------------------- Player ---------------------- */

    /**
     * Método para escoger la aventura que se jugará
     * 
     * @param choice choice.
     */
    public void setAdventureToPlay(int choice)
    {
        int index = choice - 1;
        this.adventureToPlayer = this.getAdventuresName().get(index);
    }

    /**
     * Devuelve el nombre de la aventura actual.
     * 
     * @return String con el nombre de la aventura.
     */
    public String getAdventureToPlay()
    {
        return adventureToPlayer;
    }

    /* ---------------------- Jugar una aventura ---------------------- */

    /**
     * Método que devuelve el número de combates
     * de una aventura.
     * 
     * @return Número de combates.
     */
    public int getNumCombats()
    {
        List<Adventure> adventureList = this.getAdventures();
        String adventureCombat = this.getAdventureToPlay();
        for(Adventure adventure : adventureList)
        {
            if(adventure.getName().equals(adventureCombat))
            {
                this.combats = adventure.getCombats(); 
                return adventure.getCombats().size();
            }
        }
        return -1;
    }

    /**
     * Método que devuelve la lista de monstruos
     * del combate actual.
     *
     * @return Lista de monstruos.
     */
    public List<Monster> getMonstersOfCombat()
    {
        return this.monstersToActualCombat;
    }

    /**
     * Método que devuelve la cantidad y nombre
     * de los monstruos del combate actual.
     * 
     * @param index Index del monster.
     * @return Lista de Strings con la información de los monstruos.
     */
    public List<String> getMonstersInfo(int index)
    {
        List<String> monsterInfo = new ArrayList<>();
        this.quantityMonstersToActualCombat = new ArrayList<>();
        for(QuantityMonster monster : this.combats.get(index).getMonsters())
        {
            this.quantityMonstersToActualCombat.add(monster);
            Monster monsterPlay = monster.getMonster();
            String name = monsterPlay.getName();
            int quantity = monster.getQuantity();
            monsterInfo.add(buildMonsterInfo(name, quantity));
        }

        return monsterInfo;
    }

    /**
     * Método que devuelve el monstruo y su cantidad
     * 
     * @param name Nombre del monstruo.
     * @param quantity Cantidad del monstruo y el monstruo.
     * @return Monster con su cantidad.
     */
    private String buildMonsterInfo(String name, int quantity)
    {
        return  quantity + "x " + name;
    }

    /* ---------------------- Preparation ---------------------- */

    /**
     * Función random dentro de un rango
     *
     * @return Devuelve el número random.
     */
    private int random()
    {
        return (int) (Math.random() * (12 - 1)) + 1;
    }

    /**
     * Método que genera un dado de 12 caras.
     * @return Devuelve el número random.
     */
    private int generateDice12()
    {
        return random();
    }

    /**
     * Método que crea la iniciativa de los monstruos
     * de un combate
     */
    public void createInitiative()
    {
        this.monstersToActualCombat = new ArrayList<>();
        for(QuantityMonster quantityMonster : this.quantityMonstersToActualCombat)
        {
            for(int i = 0; i < quantityMonster.getQuantity(); i++)
            {
                if(quantityMonster.getMonster().getChallenge().equals("Boss"))
                {
                    MonsterBoss monsterBoss = new MonsterBoss(quantityMonster.getMonster());
                    int dice = this.generateDice12();
                    monsterBoss.sumInitiative(dice);
                    this.monstersToActualCombat.add(monsterBoss);
                }
                else
                {
                    Monster monster = new Monster(quantityMonster.getMonster());
                    int dice = this.generateDice12();
                    monster.sumInitiative(dice);
                    this.monstersToActualCombat.add(monster);
                }
            }
        }
    }

    /**
     * Método que devuelve el monstruo con su iniciativa
     * de un combate
     * 
     * @return Lista de Strings con la información de los monstruos.
     */
    public List<String> rollingInitiative()
    {
        List<String> strings = new ArrayList<>();
        for(Monster monster : this.monstersToActualCombat)
        {
            strings.add(monster.getInitiative() + " " + monster.getName());
        }
        return strings;
    }
}