package Business.Adventure;

import java.util.List;

public class Adventure
{
    private String name;
    private int numberOfCombats;
    private List<Combat> combats;

    /**
     * Constructor de la clase Aventura.
     * @param name Nombre de la aventura.
     * @param numberOfCombats Número de combates de la aventura.
     * @param combats Lista de combates de la aventura.
     */
    public Adventure(String name, int numberOfCombats, List<Combat> combats)
    {
        this.name = name;
        this.numberOfCombats = numberOfCombats;
        this.combats = combats;
    }

    /**
     * Get Name.
     * @return Adventure name.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Set nombre de aventura
     * @param name Adventure name.
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Get número de combates de la aventura
     * @return Adventure encounters.
     */
    public int getNumberOfCombats()
    {
        return numberOfCombats;
    }

    /**
     * Set número de combates de la aventura.
     * @param numberOfCombats Adventure encounters.
     */
    public void setNumberOfCombats(int numberOfCombats)
    {
        this.numberOfCombats = numberOfCombats;
    }

    /**
     * Get lista de combates de la aventura.
     * @return Adventure combat.
     */
    public List<Combat> getCombats()
    {
        return combats;
    }

    /**
     * Set lista de combates de la aventura.
     * @param combats Adventure combat.
     */
    public void setCombats(List<Combat> combats)
    {
        this.combats = combats;
    }
}