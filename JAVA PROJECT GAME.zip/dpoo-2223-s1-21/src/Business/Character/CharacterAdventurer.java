package Business.Character;

public class CharacterAdventurer extends Character
{
    /**
     * Constructor del Personaje Champion.
     *
     * @param name The Name.
     * @param player The Player.
     * @param xp The Xp.
     * @param body The Body.
     * @param mind The Mind.
     * @param spirit The Spirit.
     * @param clase The Class.
     */
    public CharacterAdventurer(String name, String player, int xp,
        int body, int mind, int spirit, String clase, String damageType)
    {
        super(name, player, xp, body, mind, spirit, clase, damageType);
    }

    /**
     * Constructor de copia de un personaje
     *
     * @param character El personaje a copiar.
     */
    public CharacterAdventurer(Character character)
    {
        super(character);
    }

    /**
     * Calcular la iniciativa a partir de un dado de 12 caras y el spirit.
     */
    public void initiative()
    {
        int dice = this.random(1, 12);
        this.setInitiative(dice + this.getSpirit());
    }
    
    /**
     * Método para inicializar la vida actual
     * a los puntos máximos de un personaje
     */
    @Override
    public void initializeActualLife()
    {
        this.setActualLife(this.getMaxLife());
    }

    /**
     * Método para inicializar los puntos de vida de un personaje al máximo.
     */
    @Override
    public void maximumHitPoint()
    {
        int level = this.experienceToLevel();
        int life = (10 + this.getBody()) * level;
        this.setMaxLife(life);
        this.initializeActualLife();
    }

    /**
     * Método que devuelve la intensidad de un ataque
     * de un personaje en puntos
     *
     * @param attack El ataque.
     * @return La intensidad del ataque.
     */
    public int swordSlash(int attack)
    {
        int diceSixFaces = this.random(1, 6);

        int hit = 0;

        if(attack > 1 && attack < 10)
        {
            hit = diceSixFaces + this.getBody();
        }

        if(attack == 10)
        {
            hit = (diceSixFaces + this.getBody()) * 2;
        }

        return hit;
    }

    /**
     * Método que disminuye la vida de un personaje.
     */
    @Override
    public void decreaseLife(int pintos, String damageType)
    {
        this.setActualLife(this.getActualLife() - pintos);
    }
}