package Business.Character;

import Business.Monster.Monster;
import Business.Monster.MonsterManager;
import Persistence.Character.CharacterApiDAO;
import Persistence.Character.CharacterDAO;
import Persistence.Character.CharacterJsonDAO;
import Presentation.MenuOptions;

import java.util.*;

public class CharacterManager
{
    private CharacterDAO characterDAO;
    private MonsterManager monsterManager;
    private List<Character> charactersToPlay;
    private Character characterPlaying;
    private int attack;
    private int swordSlash;
    private boolean isDies = false;
    private List<Character> deadCharacters = new ArrayList<>();
    private List<String> charactersNameToPlay;
    private List<String> charactersDeadName;
    private String postedCharacterClass;

    /**
     * Constructor del Character Manager
     */
    public CharacterManager(MenuOptions menuOptions)
    {
        switch(menuOptions)
        {
            case LOCAL_DATA -> this.characterDAO = new CharacterJsonDAO();
            case CLOUD_DATA -> this.characterDAO = new CharacterApiDAO();
        }
    }

    /**
     * Inicializar monster manager
     * @param monsterManager Monster Manager.
     */
    public void startMonster(MonsterManager monsterManager)
    {
        this.monsterManager = monsterManager;
    }

    /**
     * Comprobar que el fichero .josn del Character existe.
     *
     * @return Devuelve true si existe el fichero y false si no existe.
     */
    public boolean isExist(MenuOptions options)
    {
        boolean isExistDirectory =
            this.characterDAO.isExistDirectory();
        boolean isExistFile = this.characterDAO.isExistFile();

        switch(options)
        {
            case LOCAL_DATA ->
            {
                if(isExistDirectory)
                {
                    if(isExistFile)
                    {
                        return true;
                    }
                    else
                    {
                        return this.characterDAO.createFile();
                    }
                }
                else
                {
                    return this.characterDAO.createDirectory();
                }
            }
            case CLOUD_DATA ->
            {
                return isExistDirectory;
            }
        }

        System.exit(0);
        return false;
    }

    /**
     * Crear un personaje.
     * 
     * @param name Name.
     * @param player Player.
     * @param level Level.
     * @param body Body.
     * @param mind Mind.
     * @param spirit Spirit.
     * @return Devuelve un booleano si el personaje se ha creado o no.
     */
    public boolean postCharacter(String name, String player,
        int level, int body, int mind, int spirit, String clase)
    {
        int xp = levelToExperience(level);
        Character character = null;
        
        switch(clase)
        {
            case "Adventurer" -> {
                if(level > 0 && level < 4)
                {
                    character = new CharacterAdventurer(name, player, xp, body, mind, spirit, clase, "Physical");
                }
                else if(level > 3 && level < 8)
                {
                    character = new CharacterWarrior(name, player, xp, body, mind, spirit, "Warrior", "Physical");
                }
                else
                {
                    character = new CharacterChampion(name, player, xp, body, mind, spirit, "Champion", "Physical");
                }
            }
            case "Cleric" -> {
                if(level > 0 && level < 5)
                {
                    character = new CharacterCleric(name, player, xp, body, mind, spirit, "Cleric", "Psychical");
                }
                else
                {
                    character = new CharacterPaladi(name, player, xp, body, mind, spirit, "Paladi", "Psychical");
                }
            }
            case "Mage" -> character = new CharacterMagician(name, player, xp, body, mind, spirit, "Magician", "Magical");
        }

        assert character != null;
        this.postedCharacterClass = character.getClase();

        return this.characterDAO.postCharacter(character);
    }

    /**
     * Método que devuelve la clase del personaje recien cargado
     *
     * @return clase del personaje.
     */
    public String getPostedCharacterClass()
    {
        return postedCharacterClass;
    }

    /**
     * Lista de todos los personajes con todos sus datos.
     * 
     * @return Lista de Personajes.
     */
    private List<Character> getCharacters()
    {
        return this.characterDAO.getCharacters();
    }

    /**
     * Lista de los nombres de todos los personajes.
     * 
     * @return Lista de strings con el nombre de los personajes.
     */
    public List<String> getCharactersName()
    {
        return this.characterDAO.getCharactersName();
    }

    /**
     * Método que devuelve los personajes por nombre
     * @param name Nombre del personaje.
     * @return Devuelve un personaje.
     */
    private List<Character> getCharacterByName(String name)
    {
        Map<String, String> attributes = new HashMap<>();
        attributes.put("name", name);

        return this.characterDAO.getCharactersByFields(attributes);
    }

    /**
     * Método que devuelve los personajes por jugador
     * @param player Nombre del jugador.
     * @return Devuelve un personaje.
     */
    private List<Character> getCharacterByPlayer(String player)
    {
        Map<String, String> attributes = new HashMap<>();
        attributes.put("player", player);

        return this.characterDAO.getCharactersByFields(attributes);
    }

    /**
     * Método que elimina los personajes por nombre
     * @param name Nombre del personaje.
     * @return Devuelve un booleano si el personaje se ha eliminado o no.
     */
    public boolean deleteCharacterByName(String name)
    {
        Map<String, String> attributes = new HashMap<>();
        attributes.put("name", name);

        return this.characterDAO.deleteCharacterByFields(attributes);
    }

    /**
     * Método que devuelve el tamaño de la lista de personajes
     * @return Devuelve el tamaño de la lista de personajes.
     */
    public int size()
    {
        return getCharacters().size();
    }

    /**
     * Método que verifica que un personaje no
     * exista previamente
     *
     * @param name Nombre del personaje.
     * @return Devuelve un booleano si el personaje existe o no.
     */
    public boolean alreadyExistCharacter(String name)
    {
        List<Character> characters = getCharacters();
        for(Character character : characters)
        {
            if (character.getName().contains(name.toLowerCase())
                || character.getName().contains(name.toUpperCase())
                || character.getName().contains(name))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Método para generar la suma de 2 dados
     * de 6 caras.
     *
     * @return Devuelve una array de int con el resultado del primer dado, el segundo y la suma de los dos.
     */
    public int[] generateSumOfDiceSixFaces()
    {
        int dice1 = random(1, 6);
        int dice2 = random(1, 6);

        int sumDice = dice1 + dice2;

        return new int[] {dice1, dice2, sumDice};
    }

    /**
     * Método para asignar las estadísticas de un personaje
     *
     * @param value Valor de la suma de los dados.
     * @return Devuelve un int con el valor de la estadística.
     */
    public int resultOfDice(int value)
    {
        if(value == 2)
        {
            return -1;
        }
        else if(value >= 3 && value <= 5)
        {
            return +0;
        }
        else if(value >= 6 && value <= 9)
        {
            return +1;
        }
        else if(value >= 10 && value <= 11)
        {
            return +2;
        }
        else
        {
            return +3;
        }
    }

    /**
     * Pasar del level al experience.
     * 
     * @param level Nivel.
     * @return Devuelve el experience.
     */
    private int levelToExperience(int level)
    {
        if(level == 1)
        {
            return random(0, 99);
        }
        else if(level == 2)
        {
            return random(100, 199);
        }
        else if(level == 3)
        {
            return random(200, 299);
        }
        else if(level == 4)
        {
            return random(300, 399);
        }
        else if(level == 5)
        {
            return random(400, 499);
        }
        else if(level == 6)
        {
            return random(500, 599);
        }
        else if(level == 7)
        {
            return random(600, 699);
        }
        else if(level == 8)
        {
            return random(700, 799);
        }
        else if(level == 9)
        {
            return random(800, 899);
        }
        else
        {
            return random(900, 100000);
        }
    }

    /**
     * Sacar un dado.
     *
     * @param numMin El número mínimo que puede obtener.
     * @param numMax El número máximo que puede obtener.
     * @return Devuelve el número del dado.
     */
    private int random(int numMin, int numMax)
    {
        return (int) (Math.random() * (numMax - numMin)) + numMin;
    }

    /**
     * Método que verificar y devuelve si un jugador
     * existe previamente.
     *
     * @param name Nombre del jugador.
     * @return Devuelve el nombre del jugador.
     */
    public String isExistsAndReturnPlayer(String name)
    {
        List<String> charactersPlayer =
                this.characterDAO.getCharactersPlayer();
        for(String player : charactersPlayer)
        {
            if (player.contains(name.toLowerCase())
                    || player.contains(name.toUpperCase())
                    || player.contains(name)
                    || player.toLowerCase().contains(name.toLowerCase()))
            {
                return player;
            }
        }
        return "";
    }

    /**
     * Método que devuelve la lista de personajes
     * creada por un jugador específico
     *
     * @param player Nombre del jugador.
     * @return Devuelve la lista de personajes.
     */
    public List<String> charactersOfPlayers(String player)
    {
        List<Character> listOfCharacters = this.getCharacterByPlayer(player);
        List<String> listOfNames = new ArrayList<>();

        for(Character characters: listOfCharacters)
        {
            listOfNames.add(characters.getName());
        }

        return listOfNames;
    }

    /**
     * Método que devuelve la informacion de un personaje
     *
     * @param characterName Nombre del personaje.
     * @return Devuelve la informacion del personaje.
     */
    public String infoCharacterByName(String characterName)
    {
        Character character = this.getCharacterByName(characterName).get(0);
        return this.buildCharacterInfo(character);
    }

    /**
     * Método que controla como devolver la información
     * de un personaje
     *
     * @param index Posición del personaje en la lista.
     * @param option Opción de la información a devolver.
     * @return Devuelve la información del personaje.
     */
    public String infoCharacterByIndex(int index, String option)
    {
        List<Character> listOfCharacters = getCharacters();
        if("characterName".equals(option))
        {
            return listOfCharacters.get(index).getName();
        }
        else
        {
            return buildCharacterInfo(listOfCharacters.get(index));
        }
    }

    /**
     * Método que construye la información completa
     * de un personaje.
     *
     * @param character Personaje.
     * @return Devuelve la información del personaje.
     */
    private String buildCharacterInfo(Character character)
    {
        StringBuilder stringBuilder = new StringBuilder();

        int level = character.experienceToLevel();
        stringBuilder.append("\n* Name: ").append(character.getName());
        stringBuilder.append("\n* Player: ").append(character.getPlayer());
        stringBuilder.append("\n* Class: ").append(character.getClase());
        stringBuilder.append("\n* Level: ").append(level);
        stringBuilder.append("\n* XP: ").append(character.getXp());
        stringBuilder.append("\n* Body: ").append(character.getBody());
        stringBuilder.append("\n* Mind: ").append(character.getMind());
        stringBuilder.append("\n* Spirit: ").append(character.getSpirit());
    
        return  stringBuilder.toString();
    }

    /**
     * Método para inicializar los puntos de vida de un personaje al máximo.
     *
     * @param characterNames Character Names.
     */
    public void startLifePoints(List<String> characterNames)
    {
        List<Character> listOfCharacters = this.getCharacters();
        this.charactersToPlay = new ArrayList<>();

        for(Character character : listOfCharacters)
        {
            if(characterNames.contains(character.getName()))
            {
                if(character instanceof CharacterAdventurer characterAdventurer)
                {
                    if(characterAdventurer instanceof CharacterWarrior characterWarrior)
                    {
                        if(characterWarrior instanceof CharacterChampion characterChampion)
                        {
                            characterChampion.maximumHitPoint();
                            characterChampion.initiative();
                        }
                        else
                        {
                            characterWarrior.maximumHitPoint();
                            characterWarrior.initiative();
                        }
                    }
                    else
                    {
                        characterAdventurer.maximumHitPoint();
                        characterAdventurer.initiative();
                    }
                }
                else if(character instanceof CharacterCleric characterCleric)
                {
                    if(characterCleric instanceof CharacterPaladi characterPaladi)
                    {
                        characterPaladi.maximumHitPoint();
                        characterPaladi.initiative();
                    }
                    else
                    {
                        characterCleric.maximumHitPoint();
                        characterCleric.initiative();
                    }
                }
                else if(character instanceof CharacterMagician characterMagician)
                {
                    characterMagician.maximumHitPoint();
                    characterMagician.initiative();
                }

                charactersToPlay.add(character);
            }
            if(characterNames.size() == charactersToPlay.size())
            {
                break;
            }
        }
    }

    /**
     * Método que incrementa el Spirit de un
     * personaje al iniciar un combate.
     */
    public String[] incrementsInPreparation()
    {
        String[] existChampionOrClericOrPaladiOrMag = new String[6];
        existChampionOrClericOrPaladiOrMag[0] = "";
        existChampionOrClericOrPaladiOrMag[1] = "";
        existChampionOrClericOrPaladiOrMag[2] = "";
        existChampionOrClericOrPaladiOrMag[3] = "";
        existChampionOrClericOrPaladiOrMag[4] = "";
        existChampionOrClericOrPaladiOrMag[5] = "";

        for(Character character : this.charactersToPlay)
        {
            if(character instanceof CharacterAdventurer characterAdventurer)
            {
                if(character.getClase().equals("Warrior") || character.getClase().equals("Adventurer"))
                {
                    characterAdventurer.incrementSpirit();
                }
                else
                {
                    if(character instanceof CharacterChampion characterChampion)
                    {
                        characterChampion.incrementSpirit(charactersToPlay);
                        existChampionOrClericOrPaladiOrMag[0] = characterChampion.getName();
                    }
                }
            }

            if(character instanceof CharacterCleric characterCleric)
            {
                if(character.getClase().equals("Cleric"))
                {
                    characterCleric.incrementSpirit(charactersToPlay);
                    existChampionOrClericOrPaladiOrMag[1] = characterCleric.getName();
                }
                else
                {
                    if(character instanceof CharacterPaladi characterPaladi)
                    {
                        int healPoints = characterPaladi.incrementSpirit(charactersToPlay);
                        existChampionOrClericOrPaladiOrMag[2] = characterPaladi.getName();
                        existChampionOrClericOrPaladiOrMag[3] = String.valueOf(healPoints);
                    }
                }
            }

            if(character instanceof CharacterMagician characterMagician)
            {
                characterMagician.generateShield();
                existChampionOrClericOrPaladiOrMag[4] = characterMagician.getName();
                existChampionOrClericOrPaladiOrMag[5] = String.valueOf(
                        characterMagician.getShield());
            }
        }

        return existChampionOrClericOrPaladiOrMag;
    }

    /**
     * Método que construye la iniciativa con su personaje
     * para mostrarla por pantalla
     *
     * @return Devuelve la iniciativa con su personaje.
     */
    public List<String> rollingInitiative()
    {
        List<String> strings = new ArrayList<>();
        for(Character character : this.charactersToPlay)
        {
            strings.add(character.getInitiative() + " " + character.getName());
        }
        return strings;
    }

    /**
     * Método que ordena la lista de personajes.
     * @param monsterInCombat Lista de monstruos en combate.
     * @return Devuelve el monstruo con más vida.
     */
    private Monster reduceOneMonstersLife(List<Monster> monsterInCombat)
    {
        int maxLife = monsterInCombat.get(0).getHitPoints();
        Monster monster = monsterInCombat.get(0);

        for(int i = 1; i < monsterInCombat.size(); i++)
        {
            if (monsterInCombat.get(i).getHitPoints() > maxLife)
            {
                maxLife = monsterInCombat.get(i).getHitPoints();
                monster = monsterInCombat.get(i);
            }
        }

        return monster;
    }

    /**
     * Clase para ordenar la lista de personajes
     * que juegan por su nivel de vida
     */
    private class sortCharactersByLifePoints implements Comparator<Character>
    {
        public int compare(Character a, Character b)
        {
            return b.getActualLife() - a.getActualLife();
        }
    }

    /**
     * Método para devolver la lista de personajes
     * que juegan ordenada por nivel de vida
     *
     * @return Lista de strings con los personajes por vida.
     */
    public List<String> characterListByLife()
    {
        List<String> stringList = new ArrayList<>();
        List<Character> listOfCharactersByLife = this.charactersToPlay;
        listOfCharactersByLife.sort(new sortCharactersByLifePoints());

        for(Character character : listOfCharactersByLife)
        {
            stringList.add(buildPartyInfoInCombat(character));
        }

       return stringList;
    }

    /**
     * Método qye devuelve el personaje con su vida en el combate
     *
     * @param character Personaje.
     * @return Devuelve el personaje con su vida en el combate.
     */
    private String buildPartyInfoInCombat(Character character)
    {
        String resultado = "";
        resultado = resultado.concat(String.format("%-20s %s/%s", character.getName(), character.getActualLife(), character.getMaxLife()));

        return resultado;
    }

    /**
     * Método que devuelve la lista de personajes
     * que sigue actualmente en combate
     *
     * @return Lista de personajes que sigue en combate.
     */
    public List<Character> getCharactersInCombat()
    {
        return this.charactersToPlay;
    }

    /**
     * Método que devuelve la lista de personajes
     * que sigue actualmente en combate
     *
     * @return Lista de personajes que sigue en combate.
     */
    public String getCharactersInCombatToPrint()
    {
        StringBuilder characters = new StringBuilder();

        for(int i = 0; i < this.charactersToPlay.size(); i++)
        {
            characters.append(this.charactersToPlay.get(i).getName());

            if(i == this.charactersToPlay.size() - 1)
            {
                characters.append(".");
            }
            else
            {
                characters.append(", ");
            }
        }

        return characters.toString();
    }

    /**
     * Método que crea la lista de personajes
     * que jugaran en una aventura
     */
    public void createCharactersNameToPlay()
    {
        this.charactersNameToPlay = new ArrayList<>();
    }

    /**
     * Método que devuelve la lista de nombres
     * de los personajes que juegan una aventura
     *
     * @return Lista de nombres de los personajes.
     */
    public List<String> getCharactersNameToPlay()
    {
        return charactersNameToPlay;
    }

    /**
     * Método que añade los personajes que jugarán
     * una aventura.
     *
     * @param position Posición del personaje.
     * @param characterName Nombre del personaje.
     * @return Un booleano si se ha añadido o no.
     */
    public boolean setCharactersNameToPlay(int position,
        String characterName)
    {
        boolean isExist = this.isExistCharactersNameToPlay(characterName);

        if(!isExist)
        {
            this.charactersNameToPlay.set(position, characterName);
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Método que verifica que no se repitan
     * los personajes de una aventura
     *
     * @param characterName Nombre del personaje.
     * @return Un booleano si existe o no.
     */
    private boolean isExistCharactersNameToPlay(String characterName)
    {
        for(String s : this.getCharactersNameToPlay())
        {
            if(s.equals(characterName))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Método que inicializa la lista de personajes
     * de una aventura
     */
    public void startEmptyList(int numberOfCharacters)
    {
        for(int i = 0; i < numberOfCharacters; i++)
        {
            this.charactersNameToPlay.add("Empty");
        }
    }

    /**
     * Método que envia a combatir a cada personaje y devuelve algunos
     * de sus atributos
     *
     * @param initiative Iniciativa del personaje.
     * @return Devuelve el nombre, el tipo de daño y la clase del personaje.
     */
    public String[] combatFight(String initiative)
    {
        List<Character> characters = this.getCharactersInCombat();
        String[] characterNameAndDamageTypeAndClass = new String[3];

        for(Character character : characters)
        {
            String nameAndInitiative = character.getInitiative() + " " + character.getName();
            if(initiative.equals(nameAndInitiative) && character.getActualLife() > 0)
            {
                this.charactersFight(character);
                characterNameAndDamageTypeAndClass[0] = character.getName();
                characterNameAndDamageTypeAndClass[1] = character.getDamageType();
                characterNameAndDamageTypeAndClass[2] = character.getClase();
                this.characterPlaying = character;
                return characterNameAndDamageTypeAndClass;
            }
        }

        characterNameAndDamageTypeAndClass[0] = "";

        return characterNameAndDamageTypeAndClass;
    }

    /**
     * Método en el que los personajes atacan a un monstruo
     * en el combate.
     */
    private void charactersFight(Character character)
    {
        int attack = this.impactOfAttack();
        int swordSlash = character.swordSlash(attack);
        this.setAttack(attack);
        this.setSwordSlash(swordSlash);
    }

    /**
     * Método que asigna el impacto del ataque de un personaje
     *
     * @param attack Impacto del ataque.
     */
    private void setAttack(int attack)
    {
        this.attack = attack;
    }

    /**
     * Método que devuelve el impacto del ataque de un personaje
     */
    public int getAttack()
    {
        return attack;
    }

    /**
     * Método para saber que impacto tendrá
     * el ataque de un personaje o monstruo
     *
     * @return Impact Of Attack.
     */
    public int impactOfAttack()
    {
        return random(1, 10);
    }

    /**
     * Método que asigna los puntos del ataque de un personaje
     *
     * @param hit Puntos del ataque.
     */
    private void setSwordSlash(int hit)
    {
        this.swordSlash = hit;
    }

    /**
     * Método que devuelve los puntos del ataque de un personaje
     */
    public int getSwordSlash()
    {
        return this.swordSlash;
    }

    /**
     * Método en el cual un monstruo ataca
     * a un personaje aleatorio y en caso de quedar
     * sin vida lo elimina del combate
     *
     * @param points Puntos.
     */
    public List<String> attackMonsterToCharacter(int points)
    {
        List<Character> characterInCombat = this.getCharactersInCombat();
        List<String> charactersName = new ArrayList<>();

        List<Character> characters = 
            this.monsterManager.attackMonster(points, characterInCombat, deadCharacters.size());
        this.charactersDeadName = new ArrayList<>();

        for(Character character : characters)
        {
            if(character.getActualLife() < 1)
            {
                if(!this.deadCharacters.contains(character))
                {
                    this.deadCharacters.add(character);
                }
                this.setDies(true);
                int index = this.getCharactersInCombat().indexOf(character);
                this.getCharactersInCombat().get(index).setActualLife(0);
                this.charactersDeadName.add(character.getName());
            }
            else
            {
                this.setDies(false);
            }
            
            charactersName.add(character.getName());
        }

        return charactersName;
    }

    /**
     * Método que devuelve los nombres de los personajes muertos
     * en el combate
     *
     * @return Nombres de los personajes muertos.
     */
    public List<String> getCharactersDeadName()
    {
        return charactersDeadName;
    }

    /**
     * Método para saber si un personaje se ha muerto o no.
     * @return Devuelve true si se ha muerto y false si no.
     */
    public boolean isDies()
    {
        return isDies;
    }

    /**
     * Método para indicar que un personaje se ha muerto.
     */
    private void setDies(boolean isDies)
    {
        this.isDies = isDies;
    }

    /**
     * Método para obtener el número de personajes
     * muertos hasta el momento.
     *
     * @return Número de personajes muertos.
     */
    public int getCountDeadCharacters()
    {
        return deadCharacters.size();
    }

    /**
     * Método para reiniciar el contador al terminar el combate.
     */
    public void restartCountDeadCharacters()
    {
        this.deadCharacters = new ArrayList<>();
    }

    /**
     * Método que incrementa la experiencia de un personaje
     * después de un combate
     *
     * @param totalSumExperience Experiencia total.
     */
    public void addNewExperienceToCharacters(int totalSumExperience)
    {
        List<Character> characters = this.getCharactersInCombat();

        for(Character character : characters)
        {
            int sum = totalSumExperience + character.getXp();
            character.setXp(sum);
            
            if(character.getXp() >= 100)
            {
                character.initializeActualLife();
            }
        }
    }

    /**
     * Método que construye la información cuando un personaje sube de nivel
     *
     * @param totalSumExperience Experiencia total.
     * @return El mensaje a mostrar.
     */
    public List<String> increaseCharacterLevel(int totalSumExperience)
    {
        List<Character> characters = this.getCharactersInCombat();
        List<String> strings = new ArrayList<>();

        for(Character character : characters)
        {
            strings.add(this.buildAndIncreaseCharacterLevel(character, totalSumExperience));
        }

        return strings;
    }

    /**
     * Método que incrementa el nivel de un personaje
     *
     * @param character Personaje.
     * @param totalSumExperience Experiencia total.
     * @return El mensaje a mostrar.
     */
    private String buildAndIncreaseCharacterLevel(Character character, int totalSumExperience)
    {
        String infoAndClass = "";
        
        infoAndClass = character.getName() + " gains " + totalSumExperience + " xp. ";

        if(character.getXp() >= 100)
        {
            int index = this.charactersToPlay.indexOf(character);
            int level = character.experienceToLevel();
            infoAndClass += character.getName() + " levels up. They are now lvl " + level + "!";

            if(character instanceof CharacterAdventurer characterAdventurer)
            {
                if(characterAdventurer instanceof CharacterWarrior characterWarrior)
                {
                    if(level > 7 && characterWarrior.getClase().equals("Warrior"))
                    {
                        CharacterChampion characterChampion = new CharacterChampion(characterWarrior);
                        characterChampion.setClase("Champion");
                        this.charactersToPlay.set(index, characterChampion);
                        infoAndClass += "\n" + characterChampion.getName() + " evolves to " + characterChampion.getClase() + "!";
                    }
                }
                else if(level > 3 && level < 8 && characterAdventurer.getClase().equals("Adventurer"))
                {
                    CharacterWarrior characterWarrior = new CharacterWarrior(characterAdventurer);
                    characterWarrior.setClase("Warrior");
                    this.charactersToPlay.set(index, characterWarrior);
                    infoAndClass += "\n" + characterWarrior.getName() + " evolves to " + characterWarrior.getClase() + "!";
                }

            }
            else if(character instanceof CharacterCleric characterCleric)
            {
                if(level > 4 && characterCleric.getClase().equals("Cleric"))
                {
                    CharacterPaladi characterPaladi = (CharacterPaladi) characterCleric;
                    characterPaladi.setClase("Paladi");
                    this.charactersToPlay.set(index, characterPaladi);
                    infoAndClass += "\n" + characterPaladi.getName() + " evolves to " + characterPaladi.getClase() + "!";
                }
            }
        }

        return infoAndClass;
    }

    /**
     * Método que incrementa la vida de los personajes después de un combate
     * @return La información de los personajes que han subido de nivel.
     */
    public List<String> bandageTimeAndReturnsTheResult()
    {
        List<Character> characters = this.getCharactersInCombat();
        List<String> bandageTimeInfos = new ArrayList<>();

        for(Character character : characters)
        {
            int dice = random(1, 8);
            
            if(character.getActualLife() > 0)
            {
                int sumLife = 0;

                if(character instanceof CharacterChampion characterChampion)
                {
                    if(character.getClase().equals("Champion"))
                    {
                        characterChampion.bandageTime();
                        bandageTimeInfos.add(
                                this.buildNewPoints(character,
                                                    sumLife));
                    }
                }
                else if(character instanceof CharacterCleric characterCleric)
                {
                    if(character.getClase().equals("Cleric"))
                    {
                        sumLife = characterCleric.bandageTime();
                        bandageTimeInfos.add(
                                this.buildNewPoints(character,
                                                    sumLife));
                    }
                    else
                    {
                        if(character instanceof CharacterPaladi characterPaladi)
                        {
                            sumLife = characterPaladi.bandageTime(this.charactersToPlay, character);

                            bandageTimeInfos.add(this.buildNewPoints
                                    (character.getName(), this.getCharactersInCombatToPrint(), sumLife));
                        }
                    }
                }
                else if(character instanceof CharacterMagician characterMagician)
                {
                    bandageTimeInfos.add(this.buildNewPoints(character.getName()));
                }
                else
                {
                    int maxLife = character.getMaxLife();
                    int actualLife = character.getActualLife();
                    sumLife = dice + character.getMind();
                    int newLife = sumLife + actualLife;

                    character.setActualLife(
                            Math.min(newLife, maxLife));
                    bandageTimeInfos.add(
                            this.buildNewPoints(character, sumLife));
                }
            }
            else
            {
                bandageTimeInfos.add(this.buildNewPoints(character));
            }
        }

        return bandageTimeInfos;
    }

    /**
     * Método que mostrara por pantalla los puntos de vida incrementados
     * al terminar un combate
     *
     * @param character Personaje.
     * @param sumLife Puntos de vida incrementados.
     * @return El mensaje a mostrar.
     */
    private String buildNewPoints(Character character, int sumLife)
    {
        if(character instanceof CharacterChampion characterChampion)
        {
            return character.getName() + " uses Improved bandage time. Heals " + sumLife + " hit points.";
        }

        if(character instanceof CharacterCleric characterCleric)
        {
            return character.getName() + " uses Prayer of self-healing. Heals " + sumLife + " hit points.";
        }

        return character.getName() + " uses Bandage time. Heals " + sumLife + " hit points.";
    }

    /**
     * Método que mostrara por pantalla los puntos de vida incrementados
     * al terminar un combate
     *
     * @param charactersPlaying Personajes que están en combate.
     * @return El mensaje a mostrar.
     */
    private String buildNewPoints(String characterName, String charactersPlaying, int sumlife)
    {
        return characterName + " uses Prayer of mass healing. Heals " + sumlife + " hit points to " + charactersPlaying;
    }

    /**
     * Método que muestra por pantalla cuando un personaje ha muerto
     * después del combate
     *
     * @param character Personaje.
     * @return El mensaje a mostrar.
     */
    private String buildNewPoints(Character character)
    {
        return character.getName() + " is unconscious.";
    }

    /**
     * Método que muestra por pantalla el descanso
     * de un mago
     *
     * @param characterName Nombre del personaje.
     * @return El mensaje a mostrar.
     */
    private String buildNewPoints(String characterName)
    {
        return characterName + " is reading a book.";
    }

    /**
     * Método que muestra por pantalla el descanso
     * de un cleric.
     *
     * @return El mensaje a mostrar.
     */
    public String[] attackCharacterCleric()
    {
        if(this.characterPlaying instanceof  CharacterCleric characterCleric)
        {
            String[] returnValuesCleric = new String[3];
    
            for(Character character : this.getCharactersInCombat())
            {
                if(character.getActualLife() < (character.getMaxLife() / 2) && !character.getClase().equals("Cleric"))
                {
                    int newPoints = characterCleric.attack(character);

                    returnValuesCleric[0] = "Curacion";
                    returnValuesCleric[1] = String.valueOf(newPoints);
                    returnValuesCleric[2] = character.getName();
    
                    return returnValuesCleric;
                }
            }
        }

        return null;
    }
    
    /**
     * Método que muestra por pantalla el descanso
     * de un paladin.
     *
     * @return El mensaje a mostrar.
     */
    public String[] attackCharacterPaladi()
    {
        if(this.characterPlaying instanceof CharacterPaladi characterPaladi)
        {
            String[] returnValuesPaladi = new String[3];

            for(Character character : this.getCharactersInCombat())
            {
                if(character.getActualLife() < (character.getMaxLife() / 2))
                {
                    int newPoints = characterPaladi.attack(character);

                    for(Character character1 : this.getCharactersInCombat())
                    {
                        int newActualLife = character1.getActualLife() + newPoints;
                        character1.setActualLife(newActualLife);
                        if(deadCharacters.contains(character1) && character1.getActualLife() > 0)
                        {
                            deadCharacters.remove(character1);
                        }
                    }

                    returnValuesPaladi[0] = "Curacion";
                    returnValuesPaladi[1] = String.valueOf(newPoints);
                    returnValuesPaladi[2] = "nada";

                    return returnValuesPaladi;
                }
            }
        }

        return null;
    }

    /**
     * Método que muestra por pantalla el descanso
     * de un mago.
     *
     * @return El mensaje a mostrar.
     */
    public String[] attackCharacterMag(List<Monster> monstersInCombat, int attack)
    {
        if(this.characterPlaying instanceof CharacterMagician characterMagician)
        {
            if(monstersInCombat.size() > 2)
            {
                String[] points = new String[3];
                int poinsToUse = characterMagician.attackAllMonsters(attack);
                points[0] = String.valueOf(poinsToUse);
                points[1] = "Fireball";

                return points;
            }
            else
            {
                String[] points = new String[3];
                Monster monsters = this.reduceOneMonstersLife(monstersInCombat);
                int pointsToUse = characterMagician.attackOneMonster(attack, monsters);
                points[0] = String.valueOf(pointsToUse);
                points[1] = "Arcane";
                points[2] = monsters.getName();

                return points;
            }
        }

        return null;
    }

    /**
     * Método para saber si un monstruo muere.
     * 
     * @param points Puntos de vida a reducir.
     * @param monster Monstruo.
     * @return El monstruo muerto.
     */
    public Monster reduceAllMonstersLife(int points, Monster monster)
    {
        int newLife = monster.getHitPoints() - points;
        monster.setHitPoints(newLife);

        if(monster.getHitPoints() < 1)
        {
            this.monsterManager.addDeadMonsters(monster);
            this.monsterManager.setDies(true);
            return monster;
        }
        else
        {
            this.monsterManager.setDies(false);
            return null;
        }
    }
}