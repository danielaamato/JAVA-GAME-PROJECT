package Business.Character;

import Business.Monster.Monster;

public class CharacterMagician extends Character
{
    private int shield;

    /**
     * Constructor del Personaje Magician.
     *
     * @param name The Name.
     * @param player The Player.
     * @param xp The Xp.
     * @param body The Body.
     * @param mind The Mind.
     * @param spirit The Spirit.
     * @param clase The Class.
     */
    public CharacterMagician(String name, String player, int xp,
        int body, int mind, int spirit, String clase, String damageType)
    {
        super(name, player, xp, body, mind, spirit, clase, damageType);
    }

    /**
     * Método para inicializar los puntos de vida de un personaje al máximo.
     */
    @Override
    public void maximumHitPoint()
    {
        int level = this.experienceToLevel();
        int life = (10 + this.getBody()) * level;
        this.setMaxLife(life);
        this.initializeActualLife();
    }

    /**
     * Calcular la iniciativa a partir de un dado de 10 caras y el spirit.
     */
    public void initiative()
    {
        int dice = this.random(1, 20);
        this.setInitiative(dice + this.getMind());
    }

    /**
     * Método que devuelve el valor del escudo
     * del mago
     *
     * @return El valor del escudo.
     */
    public int getShield()
    {
        return shield;
    }

    /**
     * Método que actualiza el valor del escudo
     * del mago
     *
     * @param shield El valor del escudo.
     */
    public void actualiceShield(int shield)
    {
        this.shield -= shield;

        if(this.shield < 0)
        {
            int pointsToRestToLife = Math.abs(this.shield);
            int newLife = this.getActualLife() - pointsToRestToLife;
            this.setActualLife(newLife);
            this.shield = 0;
        }
    }

    /**
     * The generate shield.
     */
    public void generateShield()
    {
        int dice = this.random(1, 6);
        int level = this.experienceToLevel();
        this.shield = (dice + this.getMind()) * level;
    }

    /**
     * Método que disminuye la vida de un personaje.
     */
    @Override
    public void decreaseLife(int pintos, String damageType)
    {
        if(damageType.equals(this.getDamageType()))
        {
            int newLife = pintos - this.experienceToLevel();

            if(newLife > 0 && newLife < this.getActualLife())
            {
                this.setActualLife(this.getActualLife() - newLife);
            }
            else
            {
                this.setActualLife(0);
            }
        }
        else
        {
            this.setActualLife(this.getActualLife() - pintos);
        }
    }

    /**
     * Método calcular la vida actual de todos los monsters. 
     * @param attack El valor del ataque.
     * @return El valor de la vida actual.
     */
    public int attackAllMonsters(int attack)
    {
        int mal = 0;

        if(attack > 1 && attack < 10)
        {
            mal = this.random(1, 4) + this.getMind();
        }

        if(attack == 10)
        {
            mal = (this.random(1, 4) + this.getMind()) * 2;
        }

        return mal;
    }

    /**
     * Método calcular la vida actual de un monster. 
     * @param attack El valor del ataque.
     * @return El valor de la vida actual.
     */
    public int attackOneMonster(int attack, Monster monster)
    {
        int mal = 0;

        if(attack > 1 && attack < 10)
        {
            mal = this.random(1, 6) + this.getMind();
        }

        if(attack == 10)
        {
            mal = (this.random(1, 6) + this.getMind()) * 2;
        }

        return mal;
    }
}