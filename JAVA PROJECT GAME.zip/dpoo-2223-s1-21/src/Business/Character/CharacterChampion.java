package Business.Character;

import java.util.List;

public class CharacterChampion extends CharacterWarrior
{
    /**
     * Constructor del Personaje Champion.
     *
     * @param name The Name.
     * @param player The Player.
     * @param xp The Xp.
     * @param body The Body.
     * @param mind The Mind.
     * @param spirit The Spirit.
     * @param clase The Class.
     */
    public CharacterChampion(String name, String player, int xp,
        int body, int mind, int spirit, String clase, String damageType)
    {
        super(name, player, xp, body, mind, spirit, clase, damageType);
    }

    /**
     * Constructor de copia de un personaje
     *
     * @param character El personaje a copiar.
     */
    public CharacterChampion(Character character)
    {
        super(character);
    }

    /**
     * Método para inicializar los puntos de vida de un personaje al máximo.
     */
    @Override
    public void maximumHitPoint()
    {
        int level = this.experienceToLevel();
        int life = ((10 + this.getBody()) * level) + (this.getBody() * level);
        this.setMaxLife(life);
        this.initializeActualLife();
    }

    /**
     * Método que incrementa el spirit todos los personajes,
     * durante la etapa de preparación, si hay un personaje de
     * tipo champion
     */
    public void incrementSpirit(List<Character> charactersPlaying)
    {
        for(Character character : charactersPlaying)
        {
            character.incrementSpirit();
        }
    }

    /**
     * Método en el que el champion sube su vida al máximo
     * durante el bandage time
     */
    public void bandageTime()
    {
        int maxLife = this.getMaxLife();
        this.setActualLife(maxLife);
    }

    /**
     * Método que disminuye la vida de un personaje.
     */
    @Override
    public void decreaseLife(int pintos, String monsterDamageType)
    {
        int newPintos = pintos;
        if(monsterDamageType.equals(this.getDamageType()))
        {
            newPintos = (int) Math.floor(pintos / 2);
            this.setActualLife(this.getActualLife() - newPintos);
        }
        else
        {
            this.setActualLife(this.getActualLife() - newPintos);
        }
    }
}