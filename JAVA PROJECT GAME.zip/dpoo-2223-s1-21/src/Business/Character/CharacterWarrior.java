package Business.Character;

public class CharacterWarrior extends CharacterAdventurer
{
    /**
     * Constructor del Personaje Warrior.
     *
     * @param name The Name.
     * @param player The Player.
     * @param xp The Xp.
     * @param body The Body.
     * @param mind The Mind.
     * @param spirit The Spirit.
     * @param clase The Class.
     */
    public CharacterWarrior(String name, String player, int xp,
        int body, int mind, int spirit, String clase, String damageType)
    {
        super(name, player, xp, body, mind, spirit, clase, damageType);
    }
    
    /**
     * Constructor de copia de un personaje
     *
     * @param character El personaje a copiar.
     */
    public CharacterWarrior(Character character)
    {
        super(character);
    }
    
    /**
     * Calcular la iniciativa a partir de un dado de 12 y el spirit.
     */
    public void initiative()
    {
        int dice = this.random(1, 12);
        this.setInitiative(dice + this.getSpirit());
    }

    /**
     * Método para inicializar la vida actual
     * a los puntos máximos de un personaje
     */
    @Override
    public void initializeActualLife()
    {
        this.setActualLife(this.getMaxLife());
    }

    /**
     * Método para inicializar los puntos de vida de un personaje al máximo.
     */
    @Override
    public void maximumHitPoint()
    {
        int level = this.experienceToLevel();
        int life = (10 + this.getBody()) * level;
        this.setMaxLife(life);
        this.initializeActualLife();
    }

    /**
     * Método que devuelve la intensidad de un ataque
     * de un personaje en puntos
     *
     * @param attack El ataque.
     * @return El ataque en puntos.
     */
    @Override
    public int swordSlash(int attack)
    {
        int diceTenFaces = this.random(1, 10);
        int hit = 0;

        if(attack > 1 && attack < 10)
        {
            hit = diceTenFaces + this.getBody();
        }

        if(attack == 10)
        {
            hit = (diceTenFaces + this.getBody()) * 2;
        }
        
        return hit;
    }

    /**
     * Método que disminuye la vida de un personaje.
     */
    @Override
    public void decreaseLife(int pintos, String monsterDamageType)
    {
        int newPintos = pintos;
        if(monsterDamageType.equals(this.getDamageType()))
        {
            newPintos = (int) Math.floor(pintos / 2);
            this.setActualLife(this.getActualLife() - newPintos);
        }
        else
        {
            this.setActualLife(this.getActualLife() - newPintos);
        }
    }
}