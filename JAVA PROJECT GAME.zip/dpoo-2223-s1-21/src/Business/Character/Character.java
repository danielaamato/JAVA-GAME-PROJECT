package Business.Character;


import com.google.gson.annotations.SerializedName;

public abstract class Character
{
    private String name;
    private String player;
    private int xp;
    private int body;
    private int mind;
    private int spirit;
    @SerializedName("class")
    private String clase;
    private int maxLife;
    private int initiative;
    private int actualLife;
    private String damageType;
    /**
     * Constructor del Personaje.
     * 
     * @param name The Name.
     * @param player The Player.
     * @param xp The Xp.
     * @param body The Body.
     * @param mind The Mind.
     * @param spirit The Spirit.
     * @param clase The Class.
     */
    public Character(String name, String player, int xp, int body,
        int mind, int spirit, String clase, String damageType)
    {
        this.name = name;
        this.player = player;
        this.xp = xp;
        this.body = body;
        this.mind = mind;
        this.spirit = spirit;
        this.clase = clase;
        this.damageType = damageType;
    }

    /**
     * Constructor de copia de un personaje
     *
     * @param character El personaje a copiar.
     */
    public Character(Character character)
    {
        this.name = character.getName();
        this.player = character.getPlayer();
        this.xp = character.getXp();
        this.body = character.getBody();
        this.mind = character.getMind();
        this.spirit = character.getSpirit();
        this.clase = character.getClase();
        this.damageType = character.getDamageType();
        this.maxLife = character.getMaxLife();
        this.initiative = character.getInitiative();
        this.actualLife = character.getActualLife();
        this.damageType = character.getDamageType();
    }

    /**
     * Método que devuelve el nombre del personaje
     *
     * @return El nombre del personaje.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Método que actualiza el nombre del personaje.
     * @param name El nombre del personaje.
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Método que devuelve el nombre del jugador de este personaje
     *
     * @return El nombre del jugador.
     */
    public String getPlayer()
    {
        return player;
    }

    /**
     * Método que actualiza el nombre del jugador de este personaje.
     *
     * @param player El nombre del jugador.
     */
    public void setPlayer(String player)
    {
        this.player = player;
    }

    /**
     * Método que devuelve el nivel inicial del personaje
     *
     * @return El nivel inicial del personaje.
     */
    public int getXp()
    {
        return xp;
    }

    public void setXp(int xp)
    {
        this.xp = xp;
    }

    /**
     * Métodos que devuelven las estadísticas del personaje.
     *
     * @return Las estadísticas del personaje.
     */
    public int getBody()
    {
        return body;
    }

    /**
     * Set the value of body.
     *
     * @param body El atributo body.
     */
    public void setBody(int body)
    {
        this.body = body;
    }

    /**
     * Método que devuelve el atributo mind
     * de un personaje
     *
     * @return El atributo mind.
     */
    public int getMind()
    {
        return mind;
    }

    /**
     * Set the value of mind.
     *
     * @param mind El atributo mind.
     */
    public void setMind(int mind)
    {
        this.mind = mind;
    }

    /**
     * Método que devuelve el atributo spirit
     * de un personaje
     *
     * @return El atributo spirit.
     */
    public int getSpirit()
    {
        return spirit;
    }

    /**
     * Set the value of spirit.
     *
     * @param spirit El atributo spirit.
     */
    public void setSpirit(int spirit)
    {
        this.spirit = spirit;
    }

    /**
     * Método que devuelve la clase del personaje
     *
     * @return La clase del personaje.
     */
    public String getClase()
    {
        return clase;
    }

    /**
     * Método que actualiza la clase de un personaje
     *
     * @param clase La clase.
     */
    public void setClase(String clase)
    {
        this.clase = clase;
    }

    /**
     * Método que devuelve los puntos de vida
     * máximos de un personaje
     *
     * @return Los puntos de vida máximos.
     */
    public int getMaxLife()
    {
        return maxLife;
    }

    /**
     * Método set la vida máxima de un personaje.
     *
     * @param maxLife Max Life.
     */
    public void setMaxLife(int maxLife)
    {
        this.maxLife = maxLife;
    }

    /**
     * Método que devuelve la iniciativa del personaje
     *
     * @return La iniciativa del personaje.
     */
    public int getInitiative()
    {
        return initiative;
    }

    /**
     * Método que asigna la iniciativa del personaje
     */
    public void setInitiative(int initiative)
    {
        this.initiative = initiative;
    }

    /**
     * Método que devuelve los puntos de vida
     * actuales de un personaje
     *
     * @return Los puntos de vida actuales.
     */
    public int getActualLife()
    {
        return actualLife;
    }

    /**
     * Método que actualiza los puntos
     * de vida actuales de un personaje
     *
     * @param actualLife Los puntos de vida actuales.
     */
    public void setActualLife(int actualLife)
    {
        if(actualLife > this.maxLife)
        {
            this.actualLife = this.maxLife;
        }
        else
        {
            this.actualLife = actualLife;
        }
    }

    /**
     * Método que devuelve el tipo de daño de un personaje
     *
     * @return El tipo de daño.
     */
    public String getDamageType()
    {
        return damageType;
    }

    /**
     * Método que actualiza el tipo de daño de un personaje
     *
     * @param damageType El tipo de daño.
     */
    public void setDamageType(String damageType)
    {
        this.damageType = damageType;
    }

    /**
     * Método que incrementa el atributo spirit
     * de un personaje.
     */
    public void incrementSpirit()
    {
        this.spirit++;
    }

    /**
     * Método que incrementa el atributo mind
     * de un personaje
     */
    public void incrementMind()
    {
        this.mind++;
    }

    /**
     * Método que incrementa el atributo mind
     * de un personaje
     */
    public void incrementMindMore(int num)
    {
        this.mind = num;
    }

    /**
     * Calcular la iniciativa a partir de un dado de 12 y el spirit.
     */
    public void initiative()
    {
        int dice = this.random(1, 12);
        this.initiative = dice + this.spirit;
    }

    /**
     * Pasar de experience a level.
     *
     * @return Devuelve el nivel.
     */
    public int experienceToLevel()
    {
        return Math.min((xp / 100) + 1, 10);
    }

    /**
     * Método para inicializar la vida actual
     * a los puntos máximos de un personaje
     */
    public void initializeActualLife()
    {
        this.setActualLife(this.getMaxLife());
    }

    /**
     * Puntos de vida maximos
     */
    public void maximumHitPoint()
    {
    }

    /**
     * Sacar un dado.
     *
     * @param numMin El número mínimo que puede obtener.
     * @param numMax El número máximo que puede obtener.
     * @return Devuelve el número del dado.
     */
    protected int random(int numMin, int numMax)
    {
        return (int) (Math.random() * (numMax - numMin)) + numMin;
    }

    /**
     * Método que devuelve la intensidad de un ataque
     * de un personaje en puntos
     *
     * @param attack Attack.
     * @return Devuelve la intensidad del ataque.
     */
    public int swordSlash(int attack)
    {
        return 0;
    }

    /**
     * Método que disminuye la vida de un personaje.
     */
    public void decreaseLife(int pintos, String damageType)
    {
        this.actualLife -= pintos;
    }
}