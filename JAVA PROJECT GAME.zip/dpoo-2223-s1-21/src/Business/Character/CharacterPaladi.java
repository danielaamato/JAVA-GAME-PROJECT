package Business.Character;

import java.util.List;

public class CharacterPaladi extends CharacterCleric
{
    /**
     * Constructor del Personaje Paladi.
     *
     * @param name The Name.
     * @param player The Player.
     * @param xp The Xp.
     * @param body The Body.
     * @param mind The Mind.
     * @param spirit The Spirit.
     * @param clase The Class.
     */
    public CharacterPaladi(String name, String player, int xp,
        int body, int mind, int spirit, String clase, String damageType)
    {
        super(name, player, xp, body, mind, spirit, clase, damageType);
    }

    /**
     * Método para inicializar los puntos de vida de un personaje al máximo.
     */
    @Override
    public void maximumHitPoint()
    {
        int level = this.experienceToLevel();
        int life = (10 + this.getBody()) * level;
        this.setMaxLife(life);
        this.initializeActualLife();
    }

    /**
     * Calcular la iniciativa a partir de un dado de 10 caras y el spirit.
     */
    public void initiative()
    {
        int dice = this.random(1, 10);
        this.setInitiative(dice + this.getSpirit());
    }

    /**
     * Método que incrementa el atributo mind
     * de un personaje durante la etap de preparacion
     *
     * @return El incremento en puntos.
     */
    public int incrementSpirit(List<Character> charactersPlaying)
    {
        int num = 0;
        for(Character character : charactersPlaying)
        {
            num = this.random(1, 3);
            int newMind = num + character.getMind();
            character.incrementMindMore(newMind);
        }

        return num;
    }

    /**
     * Método que devuelve la intensidad de un ataque
     * de un personaje en puntos
     *
     * @param attack El ataque.
     * @return El ataque en puntos.
     */
    @Override
    public int swordSlash(int attack)
    {
        int diceEightFaces = this.random(1, 8);
        int hit = 0;

        if(attack > 1 && attack < 10)
        {
            hit = diceEightFaces + this.getSpirit();
        }

        if(attack == 10)
        {
            hit = (diceEightFaces + this.getSpirit()) * 2;
        }

        return hit;
    }

    /**
     * Método que devuelve la intensidad de un ataque.
     * @param character El personaje que recibe el ataque.
     * @return El ataque en puntos.
     */
    public int attack(Character character)
    {
        return this.random(1, 10) + character.getMind();
    }

    /**
     * Método en el que el cleric sube su vida
     * durante el bandage time.
     * @param characterPlaying Lista de personajes jugando.
     * @param character Personaje que se cura.
     * @return Los puntos de vida que se cura.
     */
    public int bandageTime(List<Character> characterPlaying, Character character)
    {
        int newPoints = this.attack(character);

            for(Character characters : characterPlaying)
            {
                int newActualLife = characters.getActualLife() + newPoints;
                characters.setActualLife(newActualLife);
            }

        return newPoints;
    }

    /**
     * Método que disminuye la vida de un personaje.
     */
    @Override
    public void decreaseLife(int pintos, String monsterDamageType)
    {
        int newPintos = pintos;
        if(monsterDamageType.equals(this.getDamageType()))
        {
            newPintos = (int) Math.floor(pintos / 2);
            this.setActualLife(this.getActualLife() - newPintos);
        }
        else
        {
            this.setActualLife(this.getActualLife() - newPintos);
        }
    }
}