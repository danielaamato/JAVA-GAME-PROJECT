package Business.Monster;

import Business.Character.*;
import Business.Character.Character;

import java.util.Collections;
import java.util.List;

public class Monster
{
    private String name;
    private String challenge;
    private int experience;
    private int hitPoints;
    private int initiative;
    private String damageDice;
    private String damageType;

    /**
     * Constructor del Moster.
     * 
     * @param name The Name.
     * @param challenge The Challenge.
     * @param experience The Experience.
     * @param hitPoints The Hit Points.
     * @param initiative The Initiative.
     * @param damageDice The Damage Dice.
     * @param damageType The Damage Type.
     */
    public Monster(String name, String challenge, int experience,
            int hitPoints, int initiative, String damageDice,
            String damageType)
    {
        this.name = name;
        this.challenge = challenge;
        this.experience = experience;
        this.hitPoints = hitPoints;
        this.initiative = initiative;
        this.damageDice = damageDice;
        this.damageType = damageType;
    }

    /**
     * Constructor del Moster.
     * 
     * @param monster The Moster.
     */
    public Monster(Monster monster)
    {
        this.name = monster.name;
        this.challenge = monster.challenge;
        this.experience = monster.experience;
        this.hitPoints = monster.hitPoints;
        this.initiative = monster.initiative;
        this.damageDice = monster.damageDice;
        this.damageType = monster.damageType;
    }

    /**
     * Método que devuelve el nombre de un monstruo
     *
     * @return Nombre del monstruo.
     */
    public String getName()
    {
        return name;
    }

    /**
     * Método que asigna el nombre de un monstruo
     *
     * @param name Nombre del monstruo.
     */
    public void setName(String name)
    {
        this.name = name;
    }

    /**
     * Método que devuelve el challenge de un monstruo
     *
     * @return Challenge del monstruo.
     */
    public String getChallenge()
    {
        return challenge;
    }

    /**
     * Método que asigna el challenge de un monstruo
     *
     * @param challenge Challenge del monstruo.
     */
    public void setChallenge(String challenge)
    {
        this.challenge = challenge;
    }

    /**
     * Método que devuelve la experiencia de un monstruo
     *
     * @return Experiencia del monstruo.
     */
    public int getExperience()
    {
        return experience;
    }

    /**
     * Método que asigna la experiencia de un monstruo
     *
     * @param experience Experiencia del monstruo.
     */
    public void setExperience(int experience)
    {
        this.experience = experience;
    }

    /**
     * Método que devuelve los hit points de un monstruo
     *
     * @return Hit points del monstruo.
     */
    public int getHitPoints()
    {
        return hitPoints;
    }

    /**
     * Método que asigna los hit points de un monstruo
     *
     * @param hitPoints Hit points del monstruo.
     */
    public void setHitPoints(int hitPoints)
    {
        this.hitPoints = hitPoints;
    }

    /**
     * Método que devuelve la iniciativa de un monstruo
     *
     * @return Iniciativa del monstruo.
     */
    public int getInitiative()
    {
        return initiative;
    }

    /**
     * Método que calcula la iniciativa de un monstruo
     *
     * @param dice Dado de iniciativa.
     */
    public void sumInitiative(int dice)
    {
        this.initiative += dice;
    }

    /**
     * Método que asigna la iniciativa de un monstruo
     *
     * @param initiative Iniciativa del monstruo.
     */
    public void setInitiative(int initiative)
    {
        this.initiative = initiative;
    }

    /**
     * Método que devuelve el damage dice de un monstruo
     *
     * @return Damage dice del monstruo.
     */
    public String getDamageDice()
    {
        return damageDice;
    }

    /**
     * Método que asigna el damage dice de un monstruo
     *
     * @param damageDice Damage dice del monstruo.
     */
    public void setDamageDice(String damageDice)
    {
        this.damageDice = damageDice;
    }

    /**
     * Método que devuelve el tipo de daño de un monstruo
     *
     * @return Tipo de daño del monstruo.
     */
    public String getDamageType()
    {
        return damageType;
    }

    /**
     * Método que asigna el tipo de daño de un monstruo
     *
     * @param damageType Tipo de daño del monstruo.
     */
    public void setDamageType(String damageType)
    {
        this.damageType = damageType;
    }

    /**
     * Método en el cual un monstruo ataca
     * a un personaje aleatorio y en caso de quedar
     * sin vida lo elimina del combate
     *
     * @param points Puntos de ataque.
     */
    public List<Character> attackMonster(int points, List<Character> charactersInCombat, int countDeadCharacters)
    {
        int characterInCombatSize = charactersInCombat.size();

        int random = (int) ((Math.random() * (characterInCombatSize)) + 0);

        while(charactersInCombat.get(random).getActualLife() < 1 && countDeadCharacters < characterInCombatSize)
        {
            random = (int) ((Math.random() * (characterInCombatSize)) + 0);
            if(charactersInCombat.get(random).getActualLife() == charactersInCombat.get(random).getMaxLife())
            {
                break;
            }
        }

        Character character = charactersInCombat.get(random);

        if(character instanceof CharacterAdventurer characterAdventurer)
        {
            if(characterAdventurer instanceof CharacterWarrior characterWarrior)
            {
                if(characterWarrior instanceof CharacterChampion characterChampion)
                {
                    characterChampion.decreaseLife(points, this.getDamageType());
                }
                else
                {
                    characterWarrior.decreaseLife(points, this.getDamageType());
                }
            }
            else
            {
                characterAdventurer.decreaseLife(points, this.getDamageType());
            }
        }
        else if(character instanceof CharacterCleric characterCleric)
        {
            if(character instanceof CharacterPaladi characterPaladi)
            {
                characterPaladi.decreaseLife(points, this.getDamageType());
            }
            else
            {
                characterCleric.decreaseLife(points, this.getDamageType());
            }
        }
        else if(character instanceof CharacterMagician characterMagician)
        {
            if(characterMagician.getShield() > 0)
            {
                characterMagician.actualiceShield(points);
            }
            else
            {
                characterMagician.decreaseLife(points, this.getDamageType());
            }
        }

        return Collections.singletonList(character);
    }

    /**
     * Método que disminuye la vida de un monstruo.
     *
     * @return decrease monster life.
     */
    public int decreaseMonsterLife(int attack)
    {
        int num = this.getHitPoints() - attack;

        this.setHitPoints(num);

        return 1;
    }
}