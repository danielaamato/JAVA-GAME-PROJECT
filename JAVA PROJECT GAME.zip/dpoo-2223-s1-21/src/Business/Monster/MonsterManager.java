package Business.Monster;

import Business.Adventure.AdventureManager;
import Business.Character.Character;
import Business.Character.CharacterManager;
import Persistence.Monster.MonsterApiDAO;
import Persistence.Monster.MonsterDAO;
import Persistence.Monster.MonsterJsonDAO;
import Presentation.MenuOptions;

import java.util.ArrayList;
import java.util.List;

public class MonsterManager
{
    private MonsterDAO monsterDAO;
    private final AdventureManager adventureManager;
    private final CharacterManager characterManager;
    private List<Monster> deadMonsters;
    private boolean isDies = false;
    private int hit;
    private int attack;
    private Monster monsterToAttack;

    /**
     * Constructor de Moster Manager.
     */
    public MonsterManager(AdventureManager adventureManager, CharacterManager characterManager, MenuOptions menuOptions)
    {
        switch(menuOptions)
        {
            case LOCAL_DATA -> this.monsterDAO = new MonsterJsonDAO();
            case CLOUD_DATA -> this.monsterDAO = new MonsterApiDAO();
        }
        
        this.adventureManager = adventureManager;
        this.characterManager = characterManager;
    }

    /**
     * Comprobar que el fichero .json del Monster existe.
     *
     * @return Devuelve true si existe el fichero y false si no existe.
     */
    public boolean isExist(MenuOptions options)
    {
        boolean isExistDirectory = this.monsterDAO.isExistDirectory();
        boolean isExistFile = this.monsterDAO.isExistFile();
        boolean isEmptyFile = this.monsterDAO.isNotEmptyFile();

        switch(options)
        {
            case LOCAL_DATA -> 
            {
                if(isExistDirectory)
                {
                    if(isExistFile)
                    {
                        if(isEmptyFile)
                        {
                            return true;
                        }
                        else
                        {
                            System.exit(0);
                        }
                    }
                    else
                    {
                        System.exit(0);
                    }
                }
                else
                {

                    return monsterDAO.createDirectory();
                }
            }
            case CLOUD_DATA ->
            {
                return isExistDirectory;
            }
        }

        System.exit(0);
        return false;
    }

    /**
     * Get All Monsters.
     *
     * @return Lista con todos los monsters.
     */
    private List<Monster> getMonsters()
    {
        return this.monsterDAO.getMonsters();
    }

    /**
     * List de string de todos los monsters.
     * 
     * @return Devuelve lista de string.
     */
    public List<String> listMonster()
    {
        List<Monster> monsterList = this.getMonsters();
        List<String> nameAndChallenge = new ArrayList<>();
        for(Monster monster : monsterList)
        {
            nameAndChallenge.add(buildMonsterInfo(monster));
        }
        return nameAndChallenge;
    }

    /**
     * Seleccionar un monster a partir de su posicion (índice).
     *
     * @param choice Posicion del monster (índice).
     * @return Devuelve el nombre del monster de este índice.
     */
    public String selectMonster(int choice)
    {
        int position = choice - 1;
        return this.monsterDAO.getMonstersName().get(position);
    }

    /**
     * Get monster.
     *
     * @param name Nombre del monster que queremos.
     * @return Devuelve el monster entero.
     */
    public Monster getMonster(String name)
    {
        List<Monster> monsterList = getMonsters();

        for(Monster monster : monsterList)
        {
            if(name.equals(monster.getName()))
            {
                return monster;
            }
        }
        return null;
    }

    /**
     * Build monster info.
     *
     * @param monster Datos del monster.
     * @return Cadena de string con los datos.
     */
    private String buildMonsterInfo(Monster monster)
    {
        return monster.getName() 
            + " (" 
            + monster.getChallenge() 
            + ")";
    }

    /**
     * Función random dentro de un rango
     *
     * @param numMin Número mínimo.
     * @param numMax Número máximo.
     * @return Devuelve un número aleatorio.
     */
    private int random(int numMin, int numMax)
    {
        return (int) (Math.random() * (numMax - numMin)) + numMin;
    }
    
    /**
     * Método para saber que impacto tendrá
     * el ataque de un monstruo.
     *
     * @return Devuelve un número aleatorio.
     */
    public int impactOfAttack()
    {
        return random(1, 10);
    }

    /**
     * Método en el cual un personaje ataca
     * a un monstruo aleatorio y en caso de quedar
     * sin vida lo elimina del combate
     *
     * @param swordSlash Daño de la espada.
     */
    public String[] attackCharacterToMonster(int swordSlash, String characterDamageType,
            String characterClass, int attackForMag)
    {
        String[] returnValues = new String[3];

        List<Monster> monsterInCombat = this.adventureManager.getMonstersOfCombat();

        int quantityMonsterCombat = monsterInCombat.size() - 1;

        Monster monster = null;

        if(characterClass.equals("Cleric"))
        {
            String[] returnValuesCleric = this.characterManager.attackCharacterCleric();
            if(returnValuesCleric != null)
            {
                return returnValuesCleric;
            }
        }

        if(characterClass.equals("Paladi"))
        {
            String[] returnValuesPaladi = this.characterManager.attackCharacterPaladi();
            if(returnValuesPaladi != null)
            {
                return returnValuesPaladi;
            }
        }

        if(characterClass.equals("Magician"))
        {
            String[] returnValuesMag = new String[4];
            returnValuesMag[1] = this.characterManager.attackCharacterMag(
                    monsterInCombat, attackForMag)[0];
            returnValuesMag[2] = this.characterManager.attackCharacterMag(
                    monsterInCombat, attackForMag)[1];

            int points = Integer.parseInt(returnValuesMag[1]);

            Monster deadMonstersMag;
            List<Monster> monstersRemove = new ArrayList<>();
            String listMonsterRemove = null;

            if(returnValuesMag[2].equals("Fireball"))
            {
                returnValuesMag[0] = this.getAllMonstersNameInCombatToPrint(monsterInCombat);
                int flag = 0;

                for(Monster monsters : monsterInCombat)
                {
                    deadMonstersMag = this.characterManager.reduceAllMonstersLife(
                            points, monsters);

                    if(!(deadMonstersMag == null))
                    {
                        monstersRemove.add(deadMonstersMag);
                        if(flag == 0)
                        {
                            listMonsterRemove = deadMonstersMag.getName() + ", ";
                        }
                        else
                        {
                            listMonsterRemove += deadMonstersMag.getName() + ", ";
                        }

                        flag = 1;
                    }
                }

                for(Monster monsterss : monstersRemove)
                {
                    this.adventureManager.getMonstersOfCombat()
                            .remove(monsterss);
                }

                if(flag == 1)
                {
                    returnValuesMag[3] = listMonsterRemove;
                }
                else
                {
                    returnValuesMag[3] = "nada";
                }
            }
            else
            {
                returnValuesMag[0] = this.characterManager.attackCharacterMag(monsterInCombat, attackForMag)[2];
                returnValuesMag[3] = "nada";
            }

            return returnValuesMag;
        }

        if(characterClass.equals("Champion"))
        {
            int minLife = monsterInCombat.get(0).getHitPoints();
            monster = monsterInCombat.get(0);

            for(int i = 1; i < monsterInCombat.size(); i++)
            {
                if (monsterInCombat.get(i).getHitPoints() < minLife)
                {
                    minLife = monsterInCombat.get(i).getHitPoints();
                    monster = monsterInCombat.get(i);
                }
            }
        }
        else
        {
            int random = random(0, quantityMonsterCombat);
            monster = monsterInCombat.get(random);
        }

        returnValues[0] = monster.getName();

        int sameDamageType;

        if(monster instanceof MonsterBoss monsterBoss)
        {
            sameDamageType = monsterBoss.decreaseMonsterLife(swordSlash, characterDamageType);

            returnValues[1] = String.valueOf(sameDamageType);
            returnValues[2] = "not null";

            if(monsterBoss.getHitPoints() < 1)
            {
                this.addDeadMonsters(monsterBoss);
                this.setDies(true);
                this.adventureManager.getMonstersOfCombat().remove(monsterBoss);
            }
            else
            {
                this.setDies(false);
            }
        }
        else
        {
            monster.decreaseMonsterLife(swordSlash);
            returnValues[1] = String.valueOf(swordSlash);
            returnValues[2] = "not null";

            if(monster.getHitPoints() < 1)
            {
                this.addDeadMonsters(monster);
                this.setDies(true);
                this.adventureManager.getMonstersOfCombat()
                        .remove(monster);
            }
            else
            {
                this.setDies(false);
            }
        }

        return returnValues;
    }

    /**
     * Get all monsters name in combat to print.
     * @param monsterInCombat List of monsters in combat.
     * @return String with all monsters name in combat.
     */
    private String getAllMonstersNameInCombatToPrint(List<Monster> monsterInCombat)
    {
        String monsters = new String();

        for(int i = 0; i < monsterInCombat.size(); i++)
        {
            monsters += monsterInCombat.get(i).getName();

            if(i == monsterInCombat.size() - 1)
            {
                if(monsterInCombat.get(i) instanceof MonsterBoss)
                {
                    monsters += " (Boss)";
                }
            }
            else
            {
                if(monsterInCombat.get(i) instanceof MonsterBoss)
                {
                    monsters += " (Boss), ";
                }
                else
                {
                    monsters += ", ";
                }
            }
        }

        return monsters;
    }

    /**
     * Método para saber si un monstruo se ha muerto o no.
     * 
     * @return Devuelve true si se ha muerto y false si no.
     */
    public boolean isDies()
    {
        return isDies;
    }

    /**
     * Método para indicar que un monstruo se ha muerto.
     */
    public void setDies(boolean isDies)
    {
        this.isDies = isDies;
    }

    /**
     * Método que devuelve el nombre de un monstruo
     * peleando en el combate actual.
     *
     * @param initiative Nombre del monstruo y su iniciativa.
     * @return Devuelve el nombre del monstruo.
     */
    public String[] combatFight(String initiative)
    {
        List<Monster> monsters = this.adventureManager.getMonstersOfCombat();
        String[] returnValues = new String[2];

        for(Monster monster : monsters)
        {
            String nameAndInitiative = monster.getInitiative() + " " + monster.getName();

            if(initiative.equals(nameAndInitiative))
            {
                this.monsterToAttack = monster;
                this.monstersFight(monster);
                returnValues[0] = monster.getName();
                returnValues[1] = monster.getDamageType();
                return returnValues;
            }
        }

        returnValues[0] = "";
        returnValues[1] = "";

        return returnValues;
    }

    /**
     * Método que genera el ataque de los monstruos
     * dentro de un combate
     */
    public void monstersFight(Monster monster)
    {
        int hit = 0;
        int attack = impactOfAttack();
        int maxDice = typeDice(monster);
        int randomDad = random(1, maxDice);

        if(attack > 1 && attack < 10)
        {
            hit = randomDad;
        }

        if(attack == 10)
        {
            hit = randomDad * 2;
        }

        this.setAttack(attack);
        this.setHit(hit);
    }

    /**
     * Método en el cual un monstruo ataca
     * a un personaje aleatorio y en caso de quedar
     * sin vida lo elimina del combate.
     *
     * @param points Puntos de vida del monstruo.
     * @param charactersInCombat Personajes en combate.
     * @param countDeadCharacters Número de personajes muertos.
     * @return Devuelve la lista de personajes en combate.
     */
    public List<Character> attackMonster(int points, List<Character> charactersInCombat, int countDeadCharacters)
    {
        Monster monster = this.monsterToAttack;
        List<Character> characters;

        if(monster instanceof MonsterBoss monsterBoss)
        {
            characters = monsterBoss.attackMonster(points, charactersInCombat, countDeadCharacters);
        }
        else
        {
            characters = monster.attackMonster(points, charactersInCombat, countDeadCharacters);
        }
        return characters;
    }

    /**
     * Método que devuelve el número de caras del dado
     * de un monstruo.
     * 
     * @param monster Monstruo del que se quiere saber el número de caras del dado.
     * @return Devuelve el número de caras del dado.
     */
    private int typeDice(Monster monster)
    {
        String [] stringDice = monster.getDamageDice().split("d");
        return Integer.parseInt(stringDice[1]);
    }

    /**
     * Método set para el tipo de ataque.
     * 
     * @param attack Tipo de ataque.
     */
    private void setAttack(int attack)
    {
        this.attack = attack;
    }

    /**
     * Método que devuelve el tipo de ataque.
     * 
     * @return Devuelve el tipo de ataque.
     */
    public int getAttack()
    {
        return attack;
    }

    /**
     * Método set de los puntos a eliminar por golpe.
     * 
     * @param hit Puntos a eliminar por golpe.
     */
    private void setHit(int hit)
    {
        this.hit = hit;
    }

    /**
     * Método que devuelve los puntos a eliminar por golpe.
     * 
     * @return Devuelve los puntos a eliminar por golpe.
     */
    public int getHit()
    {
        return this.hit;
    }

    /**
     * Iniciar la lista donde vamos a guardar todos los monstruos muertos.
     */
    public void newDeadMonsters()
    {
        this.deadMonsters = new ArrayList<>();
    }

    /**
     * Obtener la lista de los monstruos eliminados.
     * 
     * @return Lista de los monstruos eliminados.
     */
    public List<Monster> getDeadMonsters()
    {
        return this.deadMonsters;
    }

    /**
     * Método que añade un monstruo muerto a la lista de monstruos muertos.
     * 
     * @param deadMonsters Monstruo eliminado.
     */
    public void addDeadMonsters(Monster deadMonsters)
    {
        this.deadMonsters.add(deadMonsters);
    }

    /**
     * Suma total de los puntos de experiencia de
     * todos los monstruos muertos en un combate.
     *
     * @return Devuelve la suma total de los puntos de experiencia.
     */
    public int totalSumExperienceToDeadMonster()
    {
        List<Monster> monsters = this.getDeadMonsters();
        int sum = 0;

        for(Monster monster : monsters)
        {
            sum += monster.getExperience();
        }

        return sum;
    }
}