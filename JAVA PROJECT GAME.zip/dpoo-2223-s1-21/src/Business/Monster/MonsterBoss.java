package Business.Monster;

import Business.Character.*;
import Business.Character.Character;

import java.util.ArrayList;
import java.util.List;

public class MonsterBoss extends Monster
{
    /**
     * Constructor del Moster Boss.
     *
     * @param name The Name.
     * @param challenge The Challenge.
     * @param experience The Experience.
     * @param hitPoints The Hit Points.
     * @param initiative The Initiative.
     * @param damageDice The Damage Dice.
     * @param damageType The Damage Type.
     */
    public MonsterBoss(String name, String challenge, int experience,
        int hitPoints, int initiative, String damageDice, String damageType)
    {
        super(name, challenge, experience, hitPoints, initiative,
            damageDice, damageType);
    }

    /**
     * Constructor del Moster Boss.
     * 
     * @param monster The Moster Boss.
     */
    public MonsterBoss(Monster monster)
    {
        super(monster);
    }

    /**
     * Método para que los monstruos boss ataquen a todos los personajes disponibles
     * en un combate
     *
     * @param points The Points.
     * @param charactersInCombat The Characters In Combat.
     * @param countDeadCharacters The Count Dead Characters.
     * @return The List of Characters.
     */
    @Override
    public List<Character> attackMonster(int points, List<Character> charactersInCombat, int countDeadCharacters)
    {
        List<Character> characters = new ArrayList<>();

        for(Character character : charactersInCombat)
        {
            if(character.getActualLife() > 0)
            {
                if(character instanceof CharacterAdventurer characterAdventurer)
                {
                    if(characterAdventurer instanceof CharacterWarrior characterWarrior)
                    {
                        if(characterWarrior instanceof CharacterChampion characterChampion)
                        {
                            characterChampion.decreaseLife(points, this.getDamageType());
                            characters.add(characterChampion);
                        }
                        else
                        {
                            characterWarrior.decreaseLife(points, this.getDamageType());
                            characters.add(characterWarrior);
                        }
                    }
                    else
                    {
                        characterAdventurer.decreaseLife(points, this.getDamageType());
                        characters.add(characterAdventurer);
                    }
                }
                else if(character instanceof CharacterCleric characterCleric)
                {
                    if(character instanceof CharacterPaladi characterPaladi)
                    {
                        characterPaladi.decreaseLife(points, this.getDamageType());
                        characters.add(characterPaladi);

                    }
                    else
                    {
                        characterCleric.decreaseLife(points, this.getDamageType());
                        characters.add(characterCleric);

                    }
                }
                else if(character instanceof CharacterMagician characterMagician)
                {
                    if(characterMagician.getShield() > 0)
                    {
                        characterMagician.actualiceShield(points);
                        characters.add(characterMagician);
                    }
                    else
                    {
                        characterMagician.decreaseLife(points, this.getDamageType());
                        characters.add(characterMagician);
                    }
                }
            }
        }

        return characters;
    }

    /**
     * Método que disminuye la vida de un monstruo.
     *
     * @return Puntos que se le quita.
     */
    public int decreaseMonsterLife(int attack, String characterDamageType)
    {
        int returnValue = 0;

        if(characterDamageType.equals(this.getDamageType()))
        {
            returnValue = (int) Math.floor(attack / 2);
            int num = (this.getHitPoints() - returnValue);
            this.setHitPoints(num);
            return returnValue;
        }
        else
        {
            int num = this.getHitPoints() - attack;
            returnValue = attack;

            this.setHitPoints(num);
        }

        return returnValue;
    }
}