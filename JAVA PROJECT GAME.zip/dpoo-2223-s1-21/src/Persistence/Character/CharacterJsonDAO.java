package Persistence.Character;

import Business.Character.Character;
import Business.Character.*;
import com.google.gson.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CharacterJsonDAO implements CharacterDAO
{
    private final String PATH = "File/characters.json";
    private final File file = new File(PATH);
    private final Gson gson;

    /**
     * Constructor del JSON character
     */
    public CharacterJsonDAO()
    {
        this.gson = new GsonBuilder().setPrettyPrinting()
                .create();
    }

    /**
     * Método que comprueba que el directorio exista
     *
     * @return devuelve true si el directorio existe.
     */
    @Override
    public boolean isExistDirectory()
    {
        File directory = new File("File");
        return directory.exists();
    }

    /**
     * Método que crea el directorio.
     *
     * @return devuelve true si se ha creado el directorio.
     */
    @Override
    public boolean createDirectory()
    {
        File directory = new File("File");
        return directory.mkdirs();
    }

    /**
     * Método que comprueba que el archivo exista.
     *
     * @return devuelve true si el archivo existe.
     */
    @Override
    public boolean isExistFile()
    {
        return this.file.exists();
    }

    /**
     * Método para crear el archivo.
     * 
     * @return devuelve true si se ha creado el archivo.
     */
    @Override
    public boolean createFile()
    {
        try
        {
            return this.file.createNewFile();
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que carga un personaje nuevo
     *
     * @param character personaje a cargar.
     * @return devuelve true si se ha cargado el personaje.
     */
    @Override
    public boolean postCharacter(Character character)
    {
        // Llamamos al método toJson
        List<JsonElement> characterList = this.toJson(character);
        
        try
        {
            // Iniciamos la escritura en el fichero
            FileWriter writer = new FileWriter(PATH);
            this.gson.toJson(characterList, writer);
            writer.close();
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que devuelve todos los personajes
     *
     * @return Devuelve una lista de personajes.
     */
    @Override
    public List<Character> getCharacters()
    {
        List<Character> characters= new ArrayList<>();

        try
        {
            if(this.file.length() != 0)
            {
                JsonArray jsonArrayCharacters = JsonParser.parseString(
                        Files.readString(Paths.get(PATH))).getAsJsonArray();
    
                for(JsonElement jsonElement : jsonArrayCharacters)
                {
                    JsonElement jsonElementChallenge = jsonElement.getAsJsonObject().get("class");
    
                    if(jsonElementChallenge.getAsString().equals("Adventurer"))
                    {
                        characters.add(gson.fromJson(jsonElement, CharacterAdventurer.class));
                    }
                    else if(jsonElementChallenge.getAsString().equals("Cleric"))
                    {
                        characters.add(gson.fromJson(jsonElement, CharacterCleric.class));
                    }
                    else if(jsonElementChallenge.getAsString().equals("Paladi"))
                    {
                        characters.add(gson.fromJson(jsonElement, CharacterPaladi.class));
                    }
                    else if(jsonElementChallenge.getAsString().equals("Warrior"))
                    {
                        characters.add(gson.fromJson(jsonElement, CharacterWarrior.class));
                    }
                    else if(jsonElementChallenge.getAsString().equals("Champion"))
                    {
                        characters.add(gson.fromJson(jsonElement, CharacterChampion.class));
                    }
                    else
                    {
                        characters.add(gson.fromJson(jsonElement, CharacterMagician.class));
                    }
                }
            }
        }
        catch(IOException e)
        {
            return characters;
        }
        
        return characters;
    }

    /**
     * Método que devuelve todos los nombres de los personajes
     *
     * @return devuelve una lista de nombres de personajes.
     */
    @Override
    public List<String> getCharactersName()
    {
        List<Character> characters = this.getCharacters();
        List<String> characterNameList = new ArrayList<>();

        for(Character character : characters)
        {
            characterNameList.add(character.getName());
        }

        return characterNameList;
    }

    /**
     * Método que devuelve los jugadores
     *
     * @return devuelve una lista de jugadores.
     */
    @Override
    public List<String> getCharactersPlayer()
    {
        List<Character> characters = this.getCharacters();
        List<String> characterPlayerList = new ArrayList<>();

        for(Character character : characters)
        {
            characterPlayerList.add(character.getPlayer());
        }

        return characterPlayerList;
    }

    /**
     * Método que devuelve un personaje por su ID
     *
     * @param id ID del personaje.
     * @return devuelve un personaje.
     */
    @Override
    public Character getCharacterById(String id)
    {
        List<Character> characters = this.getCharacters();
        int index = Integer.parseInt(id);

        return characters.get(index);
    }

    /**
     * Método que devuelve personajes por atributos
     *
     * @param attributes atributos a buscar.
     * @return devuelve una lista de personajes.
     */
    @Override
    public List<Character> getCharactersByFields(
        Map<String, String> attributes)
    {
        List<Character> characters = this.getCharacters();
        List<Character> charactersByFields = new ArrayList<>();

        for (Map.Entry<String, String> entry : attributes.entrySet())
        {
            String key = entry.getKey();
            String value = entry.getValue();
            for(Character character : characters)
            {
                String player = character.getPlayer();

                if("name".equals(key))
                {
                    if(character.getName().contains(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("player".equals(key))
                {
                    if(player.contains(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("xp".equals(key))
                {
                    if(character.getXp() == Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("body".equals(key))
                {
                    if(character.getBody() == Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("mind".equals(key))
                {
                    if(character.getMind() == Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("spirit".equals(key))
                {
                    if(character.getSpirit() == Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("clase".equals(key))
                {
                    if(character.getClase().contains(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("damageType".equals(key))
                {
                    if(character.getDamageType().contains(value))
                    {
                        charactersByFields.add(character);
                    }
                }
            }
        }

        return charactersByFields;
    }

    /**
     * Método que elimina personaje por ID
     *
     * @param id ID del personaje.
     * @return devuelve true si se ha eliminado correctamente.
     */
    @Override
    public boolean deleteCharacterById(String id)
    {
        List<Character> characters = this.getCharacters();
        
        int index = Integer.parseInt(id);
        characters.remove(index);

        try
        {
            FileWriter writer = new FileWriter(PATH);
            gson.toJson(characters, writer);
            writer.close();
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que elimina personajes por atributos
     *
     * @param attributes atributos a buscar.
     * @return devuelve true si se ha eliminado correctamente.
     */
    @Override
    public boolean deleteCharacterByFields(
        Map<String, String> attributes)
    {
        List<Character> characters = this.getCharacters();
        List<Character> charactersByFields = new ArrayList<>();

        for (Map.Entry<String, String> entry : attributes.entrySet())
        {
            String key = entry.getKey();
            String value = entry.getValue();
            for(Character character : characters)
            {
                if("name".equals(key))
                {
                    if(!character.getName().equals(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("player".equals(key))
                {
                    if(!character.getPlayer().equals(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("xp".equals(key))
                {
                    if(character.getXp() != Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("body".equals(key))
                {
                    if(character.getBody() != Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("mind".equals(key))
                {
                    if(character.getMind() != Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("spirit".equals(key))
                {
                    if(character.getSpirit() != Integer.parseInt(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("clase".equals(key))
                {
                    if(!character.getClase().equals(value))
                    {
                        charactersByFields.add(character);
                    }
                }
                else if("damageType".equals(key))
                {
                    if(character.getDamageType().contains(value))
                    {
                        charactersByFields.add(character);
                    }
                }
            }
        }

        List<JsonElement> jsonElements = this.toJson(charactersByFields);

        try
        {
            FileWriter writer = new FileWriter(PATH);
            gson.toJson(jsonElements, writer);
            writer.close();
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que genera lista de json element
     *
     * @param character personaje a añadir.
     * @return devuelve lista de json element.
     */
    private List<JsonElement> toJson(Character character)
    {
        List<JsonElement> jsonElements = new ArrayList<>();

        // Crear una array nueva como auxiliar para añadir en la lista
        List<Character> characters = this.getCharacters();
        for(Character characterAux : characters)
        {
            JsonObject item = this.formatJsonObject(characterAux);
            jsonElements.add(item);
        }

        JsonObject item = this.formatJsonObject(character);
        jsonElements.add(item);

        return jsonElements;
    }

    /**
     * Método que genera lista de json element
     *
     * @param characters personajes a añadir.
     * @return devuelve lista de json element.
     */
    private List<JsonElement> toJson(List<Character> characters)
    {
        List<JsonElement> jsonElements = new ArrayList<>();

        // Crear una array nueva como auxiliar para añadir en la lista
        for(Character characterAux : characters)
        {
            JsonObject item = this.formatJsonObject(characterAux);
            jsonElements.add(item);
        }

        return jsonElements;
    }

    /**
     * Método que devuelve el json object.
     * 
     * @param character personaje a añadir.
     * @return devuelve el json object.
     */
    private JsonObject formatJsonObject(Character character)
    {
        JsonObject item = new JsonObject();
        item.addProperty("name", character.getName());
        item.addProperty("player", character.getPlayer());
        item.addProperty("xp", character.getXp());
        item.addProperty("body", character.getBody());
        item.addProperty("mind", character.getMind());
        item.addProperty("spirit", character.getSpirit());
        item.addProperty("class", character.getClase());
        item.addProperty("damageType", character.getDamageType());
        
        return item;
    }
}