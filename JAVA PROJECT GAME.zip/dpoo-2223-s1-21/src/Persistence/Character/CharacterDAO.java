package Persistence.Character;

import Business.Character.Character;

import java.util.List;
import java.util.Map;

public interface CharacterDAO
{
    boolean isExistDirectory();
    boolean createDirectory();
    boolean isExistFile();
    boolean createFile();
    boolean postCharacter(Character character);
    List<Character> getCharacters();
    List<String> getCharactersName();
    List<String> getCharactersPlayer();
    Character getCharacterById(String id);
    List<Character> getCharactersByFields(
        Map<String, String> attributes);
    public boolean deleteCharacterById(String id);
    public boolean deleteCharacterByFields(Map<String, String> attributes);
}