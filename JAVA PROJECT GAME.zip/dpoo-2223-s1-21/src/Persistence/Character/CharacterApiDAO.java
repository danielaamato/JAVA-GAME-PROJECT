package Persistence.Character;

import Business.Character.Character;
import Business.Character.*;
import Persistence.ApiHelper;
import com.google.gson.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CharacterApiDAO implements CharacterDAO
{
    private final Gson gson;
    private final String ENDPOINT = "https://balandrau.salle.url.edu/dpoo/S1-Project_GI21/characters";

    /**
     * Constructor character API
     */
    public CharacterApiDAO()
    {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Método que comprueba que exista el directorio.
     *
     * @return devuelve true si existe el directorio.
     */
    @Override
    public boolean isExistDirectory()
    {
        try
        {
            ApiHelper apiHelper = new ApiHelper();
            apiHelper.getFromUrl(ENDPOINT);
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * NO IMPLEMENTADO
     * Método para crear el directorio.
     * 
     * @return devuelve true si se ha creado el directorio.
     */
    @Override
    public boolean createDirectory()
    {
        return true;
    }

    /**
     * NO IMPLEMENTADO
     * Método que comprueba que exista el archivo.
     * 
     * @return devuelve true si existe el archivo.
     */
    @Override
    public boolean isExistFile()
    {
        return true;
    }

    /**
     * NO IMPLEMENTADO
     * Método para crear el archivo.
     *
     * @return devuelve true si se ha creado el archivo.
     */
    @Override
    public boolean createFile()
    {
        return true;
    }

    /**
     * Método para cargar un nuevo personaje
     *
     * @param character personaje a cargar.
     * @return devuelve true si se ha cargado el personaje.
     */
    @Override
    public boolean postCharacter(Character character)
    {
        JsonElement jsonElements = this.toJson(character);
        String body = this.gson.toJson(jsonElements);
        ApiHelper apiHelper;
        try
        {
            apiHelper = new ApiHelper();
            String resultApi = apiHelper.postToUrl(ENDPOINT, body);

            return resultApi.contains("OK");
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * Método que devuelve los nombres de los personajes
     *
     * @return devuelve una lista con los nombres de los personajes.
     */
    @Override
    public List<String> getCharactersName()
    {
        List<Character> characters = this.getCharacters();
        List<String> charactersName = new ArrayList<>();

        if(characters != null && !characters.isEmpty())
        {
            for(Character character : characters)
            {
                charactersName.add(character.getName());
            }
            return charactersName;
        }
        else
        {
            return null;
        }
    }

    /**
     * Método que devuelve los nombres de los jugadores
     *
     * @return devuelve una lista con los nombres de los jugadores.
     */
    @Override
    public List<String> getCharactersPlayer()
    {
        List<Character> characters = this.getCharacters();
        List<String> playersName = new ArrayList<>();

        if(characters != null && !characters.isEmpty())
        {
            for(Character character : characters)
            {
                playersName.add(character.getPlayer());
            }
            return playersName;
        }
        else
        {
            return null;
        }
    }

    /**
     * Método que devuelve todos los personajes
     *
     * @return devuelve una lista con todos los personajes.
     */
    @Override
    public List<Character> getCharacters()
    {
        List<Character> characters = new ArrayList<>();

        try
        {
            ApiHelper apiHelper = new ApiHelper();
            String resultApi = apiHelper.getFromUrl(ENDPOINT);
            JsonArray jsonArrayMonsters = JsonParser.parseString(resultApi).getAsJsonArray();

            for(JsonElement jsonElement : jsonArrayMonsters)
            {
                JsonElement jsonElementChallenge = jsonElement.getAsJsonObject().get("class");

                if(jsonElementChallenge.getAsString().equals("Adventurer"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterAdventurer.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Cleric"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterCleric.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Paladi"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterPaladi.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Warrior"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterWarrior.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Champion"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterChampion.class));
                }
                else
                {
                    characters.add(gson.fromJson(jsonElement, CharacterMagician.class));
                }

            }
        }
        catch(IOException e)
        {
            return null;
        }

        return characters;
    }

    /**
     * Método que devuelve un personaje por ID
     *
     * @param id ID del personaje.
     * @return devuelve el personaje.
     */
    @Override
    public Character getCharacterById(String id)
    {
        Character character;

        try
        {
            ApiHelper apiHelper = new ApiHelper();
            String url = String.format("%s%s%s", ENDPOINT, "/", id);
            String resultApi = apiHelper.getFromUrl(url);
            character = gson.fromJson(resultApi, Character.class);
        }
        catch(IOException e)
        {
            return null;
        }

        return character;
    }

    /**
     * Método que devuelve los personajes por atributos
     *
     * @param attributes atributos a buscar.
     * @return devuelve una lista con los personajes.
     */
    @Override
    public List<Character> getCharactersByFields(
        Map<String, String> attributes)
    {
        int count = 0;
        StringBuilder fields = new StringBuilder();
        List<Character> characters = new ArrayList<>();

        fields = getStringBuilder(attributes, count, fields);

        try
        {
            String url = String.format("%s%s%s", ENDPOINT, "?", fields);

            ApiHelper apiHelper = new ApiHelper();
            String resultApi = apiHelper.getFromUrl(url);

            JsonArray jsonArrayCharacters = JsonParser.parseString(resultApi).getAsJsonArray();

            for(JsonElement jsonElement : jsonArrayCharacters)
            {
                JsonElement jsonElementChallenge = jsonElement.getAsJsonObject().get("class");

                if(jsonElementChallenge.getAsString().equals("Adventurer"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterAdventurer.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Cleric"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterCleric.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Paladi"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterPaladi.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Warrior"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterWarrior.class));
                }
                else if(jsonElementChallenge.getAsString().equals("Champion"))
                {
                    characters.add(gson.fromJson(jsonElement, CharacterChampion.class));
                }
                else
                {
                    characters.add(gson.fromJson(jsonElement, CharacterMagician.class));
                }
            }
        }
        catch(IOException e)
        {
            return null;
        }

        return characters;
    }

    /**
     * Método que construye los atributos
     *
     * @param attributes atributos a buscar.
     * @param count contador.
     * @param fields atributos.
     * @return devuelve los atributos.
     */
    private StringBuilder getStringBuilder(
        Map<String, String> attributes, int count,
        StringBuilder fields)
    {
        for (Map.Entry<String, String> entry : attributes.entrySet())
        {
            count++;

            if(attributes.size() == 1)
            {
                fields = new StringBuilder(
                        entry.getKey() + "=" + entry.getValue());
            }
            else if(count == attributes.size())
            {
                fields = new StringBuilder(
                        entry.getKey() + "=" + entry.getValue());
            }
            else
            {
                fields.insert(0, entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        return fields;
    }

    /**
     * Método que elimina un personaje por ID
     *
     * @param id ID del personaje.
     * @return devuelve true si se ha eliminado correctamente.
     */
    @Override
    public boolean deleteCharacterById(String id)
    {
        try
        {
            ApiHelper apiHelper = new ApiHelper();
            String url = String.format("%s%s%s", ENDPOINT, "/", id);
            apiHelper.deleteFromUrl(url);
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que elimina un personaje por atributos
     *
     * @param attributes atributos a buscar.
     * @return devuelve true si se ha eliminado correctamente.
     */
    @Override
    public boolean deleteCharacterByFields(
        Map<String, String> attributes)
    {
        int count = 0;
        StringBuilder fields = new StringBuilder();

        fields = getStringBuilder(attributes, count, fields);

        try
        {
            String url = String.format("%s%s%s", ENDPOINT, "?", fields);
            ApiHelper apiHelper = new ApiHelper();
            apiHelper.deleteFromUrl(url);
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que genera un objeto json de un personaje
     *
     * @param character personaje.
     * @return devuelve el objeto json.
     */
    private JsonObject toJson(Character character)
    {
        JsonObject item = new JsonObject();
        item.addProperty("name", character.getName());
        item.addProperty("player", character.getPlayer());
        item.addProperty("xp", character.getXp());
        item.addProperty("body", character.getBody());
        item.addProperty("mind", character.getMind());
        item.addProperty("spirit", character.getSpirit());
        item.addProperty("class", character.getClase());
        item.addProperty("damageType", character.getDamageType());

        return item;
    }
}