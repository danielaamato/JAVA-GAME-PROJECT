package Persistence.Adventure;

import Business.Adventure.Adventure;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AdventureJsonDAO implements AdventureDAO
{
    private final String PATH = "File/adventures.json";
    private final File file = new File(PATH);
    private final Gson gson;

    /**
     * Constructor JSON aventura
     */
    public AdventureJsonDAO()
    {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Método que comprueba que exista el directorio
     * @return true si existe.
     */
    @Override
    public boolean isExistDirectory()
    {
        File directory = new File("File");
        return directory.exists();
    }

    /**
     * Método que crea el directorio
     * @return true si se ha creado correctamente.
     */
    @Override
    public boolean createDirectory()
    {
        File directory = new File("File");
        return directory.mkdirs();
    }

    /**
     * Método que comprueba que exista el archivo
     * @return true si existe.
     */
    @Override
    public boolean isExistFile()
    {
        return this.file.exists();
    }

    /**
     * Método para crear el archivo
     * @return true si se ha creado correctamente.
     */
    @Override
    public boolean createFile()
    {
        try
        {
            return this.file.createNewFile();
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que carga una nueva aventura
     *
     * @param adventure Aventura a cargar.
     * @return true si se ha cargado correctamente.
     */
    @Override
    public boolean postAdventure(Adventure adventure)
    {
        // Llamamos al método toJson
        List<Adventure> adventureList = toJson(adventure);

        try
        {
            // Iniciamos la escritura en el fichero
            FileWriter writer = new FileWriter(PATH);
            this.gson.toJson(adventureList, writer);
            writer.close();
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que devuelve todas las aventuras
     *
     * @return Lista de aventuras.
     */
    @Override
    public List<Adventure> getAdventures()
    {
        JsonReader jsonReader;

        Adventure[] adventures;
        try
        {
            jsonReader = new JsonReader(new FileReader(PATH));
            adventures =
                this.gson.fromJson(jsonReader, Adventure[].class);
            jsonReader.close();
        }
        catch(IOException e)
        {
            return null;
        }

        if(adventures != null)
        {
            return List.of(adventures);
        }
        else
        {
            return null;
        }
    }

    /**
     * Método que devuelve los nombres de las aventuras
     *
     * @return Lista de nombres de aventuras.
     */
    @Override
    public List<String> getAdventuresName()
    {
        JsonReader jsonReader;
        List<String> adventureNameList = new ArrayList<>();
        Adventure[] adventures;
        try
        {
            jsonReader = new JsonReader(new FileReader(PATH));

            adventures =
                    this.gson.fromJson(jsonReader, Adventure[].class);

            if(adventures != null)
            {
                for(Adventure adventure : adventures)
                {
                    adventureNameList.add(adventure.getName());
                }
            }
            else
            {
                adventureNameList = null;
            }
            jsonReader.close();
        }
        catch(IOException e)
        {
            return null;
        }

        return adventureNameList;
    }

    /**
     * Método que devuelve la lista de aventuras tipo JSON
     * @param adventure Aventura a añadir.
     * @return Lista de aventuras.
     */
    private List<Adventure> toJson(Adventure adventure)
    {
        List<Adventure> adventureList = this.getAdventures();

        // Crear una array nueva como auxiliar para añadir en la lista
        List<Adventure> characterListAux = new ArrayList<>();

        // Si el fichero NO está vacío, entras y lo guardas en la arraylist
        if(adventureList != null)
        {
            // Guardar los datos en la array auxiliar
            characterListAux.addAll(adventureList);
        }
        characterListAux.add(adventure);

        return characterListAux;
    }
}