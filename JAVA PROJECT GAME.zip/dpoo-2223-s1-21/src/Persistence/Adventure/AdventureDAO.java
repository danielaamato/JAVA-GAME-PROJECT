package Persistence.Adventure;

import Business.Adventure.Adventure;

import java.util.List;

public interface AdventureDAO
{
    boolean isExistDirectory();
    boolean createDirectory();
    boolean isExistFile();
    boolean createFile();
    boolean postAdventure(Adventure adventure);
    List<Adventure> getAdventures();
    List<String> getAdventuresName();
}