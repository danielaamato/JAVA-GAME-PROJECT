package Persistence.Adventure;

import Business.Adventure.Adventure;
import Persistence.ApiHelper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AdventureApiDAO implements AdventureDAO
{
    private final Gson gson;
    private final String ENDPOINT = "https://balandrau.salle.url.edu/dpoo/S1-Project_GI21/adventures";

    /**
     * Constructor API aventura
     */
    public AdventureApiDAO()
    {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Método que confirma que el directorio api exista
     * @return true si existe.
     */
    @Override
    public boolean isExistDirectory()
    {
        try
        {
            ApiHelper apiHelper = new ApiHelper();
            apiHelper.getFromUrl(ENDPOINT);
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que crea el directorio
     * @return true si se ha creado correctamente.
     */
    @Override
    public boolean createDirectory()
    {
        return true;
    }

    /**
     * Método que comprueba que el archivo exista
     * @return true si existe.
     */
    @Override
    public boolean isExistFile()
    {
        return true;
    }

    /**
     * Método para crear el archivo
     * @return true si se ha creado correctamente.
     */
    @Override
    public boolean createFile()
    {
        return true;
    }

    /**
     * Método para cargar una nueva aventura
     * @param adventure aventura a cargar.
     * @return true si se ha cargado correctamente.
     */
    @Override
    public boolean postAdventure(Adventure adventure)
    {
        String body = this.gson.toJson(adventure);
        ApiHelper apiHelper = null;
        try
        {
            apiHelper = new ApiHelper();
            String resultApi = apiHelper.postToUrl(ENDPOINT, body);

            return resultApi.contains("OK");
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * Método que devuelva todas las aventuras
     * @return lista de aventuras.
     */
    @Override
    public List<Adventure> getAdventures()
    {
        Adventure[] adventures;

        try
        {
            ApiHelper apiHelper = new ApiHelper();
            String resultApi = apiHelper.getFromUrl(ENDPOINT);
            adventures = gson.fromJson(resultApi, Adventure[].class);
        }
        catch(IOException e)
        {
            return null;
        }

        return List.of(adventures);
    }

    /**
     * Método que devuelve los nombres de las aventuras
     * @return lista de nombres de aventuras.
     */
    @Override
    public List<String> getAdventuresName()
    {
        List<Adventure> adventures = this.getAdventures();
        List<String> adventuresName = new ArrayList<>();
        
        if(adventures != null && !adventures.isEmpty())
        {
            for(Adventure adventure : adventures)
            {
                adventuresName.add(adventure.getName());
            }
            return adventuresName;
        }
        else
        {
            return null;
        }
    }
}