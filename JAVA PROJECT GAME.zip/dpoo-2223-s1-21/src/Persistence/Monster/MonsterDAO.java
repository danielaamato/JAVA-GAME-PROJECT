package Persistence.Monster;

import Business.Monster.Monster;

import java.util.List;
import java.util.Map;

public interface MonsterDAO
{
    boolean isExistDirectory();
    boolean createDirectory();
    boolean isExistFile();
    boolean isNotEmptyFile();
    List<Monster> getMonsters();
    List<String> getMonstersName();
    Monster getMonster(String id);
    List<Monster> getMonsterByFields(Map<String, String> attributes);
}