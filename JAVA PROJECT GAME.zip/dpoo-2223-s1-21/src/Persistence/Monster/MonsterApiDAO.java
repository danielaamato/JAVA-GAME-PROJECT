package Persistence.Monster;

import Business.Monster.Monster;
import Business.Monster.MonsterBoss;
import Persistence.ApiHelper;
import com.google.gson.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MonsterApiDAO implements MonsterDAO
{
    private final Gson gson;
    private final String ENDPOINT = "https://balandrau.salle.url.edu/dpoo/shared/monsters";

    /**
     * Constructor monster API
     */
    public MonsterApiDAO()
    {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Método que comprueba que el directorio existe
     */
    @Override
    public boolean isExistDirectory()
    {
        try
        {
            ApiHelper apiHelper = new ApiHelper();
            apiHelper.getFromUrl(ENDPOINT);
            return true;
        }
        catch(IOException e)
        {
            return false;
        }
    }

    /**
     * Método que crea el directorio
     *
     * @return boolean.
     */
    @Override
    public boolean createDirectory()
    {
        return true;
    }

    /**
     * Método que comprueba que exista el archivo
     *
     * @return boolean.
     */
    @Override
    public boolean isExistFile()
    {
        return true;
    }

    /**
     * Método que comprueba que no esté vacío el archivo
     *
     * @return boolean.
     */
    @Override
    public boolean isNotEmptyFile()
    {
        return true;
    }

    /**
     * Método que devuelve todos los monstruos
     *
     * @return List<Monster>.
     */
    @Override
    public List<Monster> getMonsters()
    {
        List<Monster> monsters = new ArrayList<>();

        try
        {
            ApiHelper apiHelper = new ApiHelper();
            String resultApi = apiHelper.getFromUrl(ENDPOINT);
            JsonArray jsonArrayMonsters = JsonParser.parseString(resultApi).getAsJsonArray();

            for(JsonElement jsonElement : jsonArrayMonsters)
            {
                JsonElement jsonElementChallenge = jsonElement.getAsJsonObject().get("challenge");
                if(jsonElementChallenge.getAsString().equals("Boss"))
                {
                    monsters.add(gson.fromJson(jsonElement, MonsterBoss.class));
                }
                else
                {
                    monsters.add(gson.fromJson(jsonElement, Monster.class));
                }
            }
        }
        catch(IOException e)
        {
            return null;
        }

        return monsters;
    }

    /**
     * Método que devuelve todos los nombres de los monstruos
     *
     * @return List<String>.
     */
    @Override
    public List<String> getMonstersName()
    {
        List<Monster> monsters = this.getMonsters();
        List<String> monsterNameList = new ArrayList<>();

        for(Monster monster : monsters)
        {
            monsterNameList.add(monster.getName());
        }

        return monsterNameList;    
    }

    /**
     * Get Monster por id
     * 
     * @param id The id.
     * @return The Moster.
     */
    @Override
    public Monster getMonster(String id)
    {
        Monster monster;
        
        try
        {
            ApiHelper apiHelper = new ApiHelper();
            String url = String.format("%s%s%s", ENDPOINT, "/", id);
            String resultApi = apiHelper.getFromUrl(url);
            monster = gson.fromJson(resultApi, Monster.class);
        }
        catch(IOException e)
        {
            return null;
        }

        return monster;
    }

    /**
     * Método que devuelve los monstruos por atributos
     *
     * @param attributes The attributes.
     * @return List<Monster>.
     */
    @Override
    public List<Monster> getMonsterByFields(Map<String, String> attributes)
    {
        int count = 0;
        StringBuilder fields = new StringBuilder();
        Monster[] monsters;

        fields = getStringBuilder(attributes, count, fields);

        try
        {
            String url = String.format("%s%s%s", ENDPOINT, "?", fields);

            ApiHelper apiHelper = new ApiHelper();
            String resultApi = apiHelper.getFromUrl(url);
            monsters = gson.fromJson(resultApi, Monster[].class);

        }
        catch(IOException e)
        {
            return null;
        }

        return List.of(monsters);
    }

    /**
     * Método que construye los atributos
     *
     * @param attributes atributos a buscar.
     * @param count contador.
     * @param fields atributos.
     * @return devuelve los atributos.
     */
    private StringBuilder getStringBuilder(
            Map<String, String> attributes, int count,
            StringBuilder fields)
    {
        for (Map.Entry<String, String> entry : attributes.entrySet())
        {
            count++;

            if(attributes.size() == 1)
            {
                fields = new StringBuilder(
                        entry.getKey() + "=" + entry.getValue());
            }
            else if(count == attributes.size())
            {
                fields = new StringBuilder(
                        entry.getKey() + "=" + entry.getValue());
            }
            else
            {
                fields.insert(0, entry.getKey() + "=" + entry.getValue() + "&");
            }
        }
        return fields;
    }

}