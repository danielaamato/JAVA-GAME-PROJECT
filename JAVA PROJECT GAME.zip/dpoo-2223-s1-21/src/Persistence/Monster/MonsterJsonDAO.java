package Persistence.Monster;

import Business.Monster.Monster;
import Business.Monster.MonsterBoss;
import com.google.gson.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MonsterJsonDAO implements MonsterDAO
{
    private final String PATH = "File/monsters.json";
    private final File file = new File(PATH);
    private final Gson gson;

    /**
     * Constructor monster JSON
     */
    public MonsterJsonDAO()
    {
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    /**
     * Método que comprueba que el directorio existe
     *
     * @return boolean.
     */
    @Override
    public boolean isExistDirectory()
    {
        File directory = new File("File");
        return directory.exists();
    }

    /**
     * Método que crea el directorio
     *
     * @return boolean.
     */
    @Override
    public boolean createDirectory()
    {
        File directory = new File("File");
        return directory.mkdirs();
    }

    /**
     * Método que comprueba que el archivo exista
     *
     * @return boolean.
     */
    @Override
    public boolean isExistFile()
    {
        return file.exists();
    }

    /**
     * Método que verifica que el archivo no esté vacío
     *
     * @return boolean.
     */
    @Override
    public boolean isNotEmptyFile()
    {
        return file.length() != 0;
    }

    /**
     * Método que devuelve todos los monstruos
     *
     * @return List<Monster>.
     */
    @Override
    public List<Monster> getMonsters()
    {
        List<Monster> monsters = new ArrayList<>();

        try
        {
            JsonArray jsonArrayMonsters = JsonParser.parseString(
                Files.readString(Paths.get(PATH))).getAsJsonArray();

            for(JsonElement jsonElement : jsonArrayMonsters)
            {
                JsonElement jsonElementChallenge = jsonElement.getAsJsonObject().get("challenge");
                if(jsonElementChallenge.getAsString().equals("Boss"))
                {
                    monsters.add(gson.fromJson(jsonElement, MonsterBoss.class));
                }
                else
                {
                    monsters.add(gson.fromJson(jsonElement, Monster.class));
                }
                
            }
        }
        catch(IOException e)
        {
            return null;
        }

        return monsters;
    }

    /**
     * Método que devuelve todos los nombres de los monstruos
     * @return List<String>.
     */
    @Override
    public List<String> getMonstersName()
    {
        List<Monster> monsters = this.getMonsters();
        List<String> monsterNameList = new ArrayList<>();

        for(Monster monster : monsters)
        {
            monsterNameList.add(monster.getName());
        }
    
        return monsterNameList;
    }

    /**
     * Método que devuelve monstruo por ID
     * @param id ID del monstruo.
     * @return Monster.
     */
    @Override
    public Monster getMonster(String id)
    {
        return null;
    }

    /**
     * Método que devuelve monstruo por atributo
     *
     * @param attributes atributos a buscar.
     * @return List<Monster>.
     */
    @Override
    public List<Monster> getMonsterByFields(Map<String, String> attributes)
    {
        List<Monster> monsters = this.getMonsters();
        List<Monster> monstersByFields = new ArrayList<>();

        for (Map.Entry<String, String> entry : attributes.entrySet())
        {
            String key = entry.getKey();
            String value = entry.getValue();
            for(Monster monster : monsters)
            {
                if("name".equals(key))
                {
                    if(monster.getName().contains(value))
                    {
                        monstersByFields.add(monster);
                    }
                }
                else if("challenge".equals(key))
                {
                    if(monster.getChallenge().equals(value))
                    {

                        monstersByFields.add(monster);
                    }
                }
                else if("experience".equals(key))
                {
                    if(monster.getExperience() == Integer.parseInt(value))
                    {
                        monstersByFields.add(monster);
                    }
                }
                else if("hitPoints".equals(key))
                {
                    if(monster.getHitPoints() == Integer.parseInt(value))
                    {
                        monstersByFields.add(monster);
                    }
                }
                else if("initiative".equals(key))
                {
                    if(monster.getInitiative() == Integer.parseInt(value))
                    {
                        monstersByFields.add(monster);
                    }
                }
                else if("damageDice".equals(key))
                {
                    if(monster.getDamageDice().equals(value))
                    {
                        monstersByFields.add(monster);
                    }
                }
                else if("damageType".equals(key))
                {
                    if(monster.getDamageType().equals(value))
                    {
                        monstersByFields.add(monster);
                    }
                }
            }
        }

        return monstersByFields;
    }
}