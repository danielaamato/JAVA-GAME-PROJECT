Created by: Daniela Amato and Sami Amin
Logo: daniela.amato, mohammedsami.amin
Subject: DPOO-2223-S1-21
Language used: java
IDE used: IntelliJ Idea

Es necesario tener la libreria: "google.code.gson" version "gson-2.10"
